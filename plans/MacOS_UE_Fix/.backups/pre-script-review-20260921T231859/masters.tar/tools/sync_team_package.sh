#!/bin/bash
# sync_team_package.sh [--push] — ON WSL. Assembles the lab's team package (plans/MacOS_UE_Fix/team-package/) from the
# masters in plans/MacOS_UE_Fix/ and, with --push, mirrors it to the Air's two copies and verifies them by md5.
#
# The team package is what a lab Mac needs to go from a blank machine to a verified Shipping app with no access to
# this repository: the engine build + migration script and its patches, the packaging scripts with their guard, the
# project-source masters (so a migrated project can be verified/re-applied), the display-survey harness and the
# documents. Masters stay where HANDOFF-2026-09-21.md §3 says; this script copies them, so never edit the copies.
#
#   masters (source of truth)                          -> team-package/ (copy)
#   graphics-autotune/check_engine_patch.sh            -> check_engine_patch.sh
#   graphics-autotune/package_mac_gfx.sh               -> package_mac_gfx.sh
#   voice-aec-fix/package_mac_shipping.sh              -> package_mac_shipping.sh
#   voice-aec-fix/build_mac_editor.sh                  -> build_mac_editor.sh
#   graphics-autotune/{mac_runtime_test,stage_gat_ini,backup_step}.sh -> same names
#   graphics-autotune/apply_autotune_src.sh + src/**   -> masters/graphics-autotune/{apply_autotune_src.sh,src/**}
#   graphics-autotune/config/Mac/MacEngine.ini         -> masters/graphics-autotune/config/Mac/MacEngine.ini
#   mac-linker/{awsTutorial.cpp,awsTutorial.Target.cs} -> masters/mac-linker/
#   voice-aec-fix/EmbeddedVoiceChat/**                 -> masters/voice-aec-fix/EmbeddedVoiceChat/**
#   engine-patches/MetalRHI-resolution-list.patch      -> patches/6g-MetalRHI-resolution-list.patch
#   (WebBrowserSingleton hunk of engine-all-local-modifications.patch) -> patches/6h-WebBrowserSingleton-CEF-fallback.patch
#   tools/mac/display_survey/**                        -> tools/display_survey/**
#   HANDOFF-2026-09-21.md                              -> docs/HANDOFF-2026-09-21.md (reference copy)
# Then writes masters/MANIFEST.tsv (md5 <TAB> master path <TAB> project path; CR-stripped md5) for
# verify-project-masters.sh / apply-project-masters.sh, and PACKAGE.md5 (every file except *.zip).
#
# --push: rsync (no --delete; zips untouched) to daltonsalvo@192.168.50.10:~/Downloads/ue541-team-package/ and
# /Volumes/KingLab/ue541-team-package/, after a tar backup of each into ~/team-package-backups/<stamp>/ on the Air;
# then every file is md5-checked on the Air against PACKAGE.md5. Also refreshes the Air's ~/gfx_autotune/ copies of
# the guarded scripts (package_mac_gfx.sh, package_mac_shipping.sh, build_mac_editor.sh, check_engine_patch.sh,
# apply_autotune_src.sh) since that is what the operator runs there.
set -eu
PUSH=0; [ "${1:-}" = "--push" ] && PUSH=1
P="$(cd "$(dirname "$0")/.." && pwd)"          # plans/MacOS_UE_Fix
T="$P/team-package"
AIR="${AIR_SSH:-daltonsalvo@192.168.50.10}"
# Remote paths (the Air's home, not this WSL one): the literal ~ is expanded by the Air's shell and by rsync.
MIRRORS=('~/Downloads/ue541-team-package' '/Volumes/KingLab/ue541-team-package')
sum() { tr -d '\r' < "$1" | md5sum | cut -c1-32; }
cp_f() { mkdir -p "$(dirname "$2")"; cp "$1" "$2"; }

echo "== assembling $T from masters in $P"
cp_f "$P/graphics-autotune/check_engine_patch.sh"  "$T/check_engine_patch.sh"
cp_f "$P/graphics-autotune/package_mac_gfx.sh"     "$T/package_mac_gfx.sh"
cp_f "$P/voice-aec-fix/package_mac_shipping.sh"    "$T/package_mac_shipping.sh"
cp_f "$P/voice-aec-fix/build_mac_editor.sh"        "$T/build_mac_editor.sh"
for s in mac_runtime_test.sh stage_gat_ini.sh backup_step.sh; do cp_f "$P/graphics-autotune/$s" "$T/$s"; done
cp_f "$P/graphics-autotune/apply_autotune_src.sh"  "$T/masters/graphics-autotune/apply_autotune_src.sh"
rm -rf "$T/masters/graphics-autotune/src" "$T/masters/voice-aec-fix" "$T/tools/display_survey"
mkdir -p "$T/masters/graphics-autotune" "$T/masters/voice-aec-fix" "$T/tools" "$T/patches" "$T/docs"
cp -R "$P/graphics-autotune/src" "$T/masters/graphics-autotune/src"
cp_f "$P/graphics-autotune/config/Mac/MacEngine.ini" "$T/masters/graphics-autotune/config/Mac/MacEngine.ini"
cp_f "$P/mac-linker/awsTutorial.cpp"       "$T/masters/mac-linker/awsTutorial.cpp"
cp_f "$P/mac-linker/awsTutorial.Target.cs" "$T/masters/mac-linker/awsTutorial.Target.cs"
cp -R "$P/voice-aec-fix/EmbeddedVoiceChat" "$T/masters/voice-aec-fix/EmbeddedVoiceChat"
find "$T/masters" -name '.DS_Store' -delete
cp_f "$P/engine-patches/MetalRHI-resolution-list.patch" "$T/patches/6g-MetalRHI-resolution-list.patch"
awk '/^diff --git.*WebBrowserSingleton/{p=1} p&&/^diff --git/&&!/WebBrowserSingleton/{p=0} p' \
  "$P/engine-patches/engine-all-local-modifications.patch" > "$T/patches/6h-WebBrowserSingleton-CEF-fallback.patch"
[ -s "$T/patches/6h-WebBrowserSingleton-CEF-fallback.patch" ] || { echo "6h patch came out empty"; exit 1; }
cp -R "$P/tools/mac/display_survey" "$T/tools/display_survey"
cp_f "$P/HANDOFF-2026-09-21.md" "$T/docs/HANDOFF-2026-09-21.md"
chmod +x "$T"/*.sh "$T"/masters/graphics-autotune/*.sh "$T"/tools/display_survey/*.sh

echo "== masters/MANIFEST.tsv"
M="$T/masters/MANIFEST.tsv"
{
  printf '# md5 (CR-stripped)\tmaster path (under masters/)\tproject path — written by tools/sync_team_package.sh %s\n' "$(date -u +%FT%TZ)"
  for f in GraphicsAutoTuneSubsystem.cpp GraphicsAutoTuneSubsystem.h MacDisplayInsets.h Mac/MacDisplayInsets.mm; do
    printf '%s\tgraphics-autotune/src/%s\tSource/awsTutorial/%s\n' "$(sum "$T/masters/graphics-autotune/src/$f")" "$f" "$f"
  done
  printf '%s\tmac-linker/awsTutorial.cpp\tSource/awsTutorial/awsTutorial.cpp\n' "$(sum "$T/masters/mac-linker/awsTutorial.cpp")"
  printf '%s\tmac-linker/awsTutorial.Target.cs\tSource/awsTutorial.Target.cs\n' "$(sum "$T/masters/mac-linker/awsTutorial.Target.cs")"
  printf '%s\tgraphics-autotune/config/Mac/MacEngine.ini\tConfig/Mac/MacEngine.ini\n' "$(sum "$T/masters/graphics-autotune/config/Mac/MacEngine.ini")"
  ( cd "$T/masters/voice-aec-fix/EmbeddedVoiceChat" && find . -type f | sort | sed 's|^\./||' ) | while read -r f; do
    printf '%s\tvoice-aec-fix/EmbeddedVoiceChat/%s\tPlugins/UltimateMultiplayerServicesPlugin/Source/EmbeddedVoiceChat/%s\n' "$(sum "$T/masters/voice-aec-fix/EmbeddedVoiceChat/$f")" "$f" "$f"
  done
  for f in Info.Template.plist NoSandbox.entitlements; do
    printf '%s\tproject-mac/Build/Mac/Resources/%s\tBuild/Mac/Resources/%s\n' "$(sum "$T/masters/project-mac/Build/Mac/Resources/$f")" "$f" "$f"
  done
} > "$M"
echo "   $(grep -vc '^#' "$M") files in the manifest"

echo "== PACKAGE.md5"
( cd "$T" && find . -type f ! -name '*.zip' ! -name PACKAGE.md5 ! -name '.DS_Store' | sort | sed 's|^\./||' | while read -r f; do printf '%s  %s\n' "$(md5sum "$f" | cut -c1-32)" "$f"; done ) > "$T/PACKAGE.md5"
echo "   $(wc -l < "$T/PACKAGE.md5") files"
for s in "$T"/*.sh "$T"/masters/graphics-autotune/*.sh "$T"/tools/display_survey/*.sh; do bash -n "$s" || { echo "SYNTAX: $s"; exit 1; }; done
echo "   bash -n: all scripts parse"
[ "$PUSH" = 1 ] || { echo "== done (no --push)"; exit 0; }

echo "== pushing to the Air ($AIR)"
STAMP=$(date +%Y%m%dT%H%M%S)
ssh -o BatchMode=yes "$AIR" "mkdir -p ~/team-package-backups/$STAMP && for d in ${MIRRORS[*]}; do [ -d \"\$d\" ] && tar -C \"\$d\" --exclude='*.zip' -cf ~/team-package-backups/$STAMP/\$(basename \$(dirname \"\$d\"))-\$(basename \"\$d\").tar . && echo \"backed up \$d\"; done; mkdir -p ~/gfx_autotune/.backups/$STAMP && cp ~/gfx_autotune/{package_mac_gfx.sh,package_mac_shipping.sh,build_mac_editor.sh,check_engine_patch.sh} ~/gfx_autotune/.backups/$STAMP/ 2>/dev/null; echo gfx_autotune backed up"
for d in "${MIRRORS[@]}"; do
  rsync -rlt --exclude '*.zip' --exclude '.DS_Store' "$T/" "$AIR:$d/"
  echo "   rsynced -> $d"
done
for s in package_mac_gfx.sh package_mac_shipping.sh build_mac_editor.sh check_engine_patch.sh; do rsync -t "$T/$s" "$AIR:~/gfx_autotune/$s"; done
rsync -t "$T/masters/graphics-autotune/apply_autotune_src.sh" "$AIR:~/gfx_autotune/apply_autotune_src.sh"
echo "   ~/gfx_autotune guarded scripts refreshed"
echo "== verifying on the Air"
ssh -o BatchMode=yes "$AIR" "for d in ${MIRRORS[*]}; do cd \"\$d\" || exit 1; bad=0; n=0; while read -r want f; do n=\$((n+1)); have=\$(md5 -q \"\$f\" 2>/dev/null); [ \"\$have\" = \"\$want\" ] || { echo \"MISMATCH \$d/\$f\"; bad=\$((bad+1)); }; done < PACKAGE.md5; echo \"\$d: \$n files, \$bad mismatches\"; done; for s in package_mac_gfx.sh package_mac_shipping.sh build_mac_editor.sh check_engine_patch.sh; do a=\$(md5 -q ~/gfx_autotune/\$s); b=\$(md5 -q ~/Downloads/ue541-team-package/\$s); [ \"\$a\" = \"\$b\" ] && echo \"gfx_autotune/\$s = team package\" || echo \"MISMATCH gfx_autotune/\$s\"; done"
echo "== done"
