#!/bin/bash
# apply-project-masters.sh <project dir> — ON ANY MACHINE. Installs every file in masters/MANIFEST.tsv into the
# project (plain copy, line endings as in the master; the project's module files use LF), adds the auto-tuner's
# module dependencies to awsTutorial.Build.cs when absent (masters/graphics-autotune/apply_autotune_src.sh), then
# runs verify-project-masters.sh. A backup of Source/, the voice plugin, Config/ and Build/Mac/ is taken first
# (backup_step.sh, into <project>/.backups/masters-<stamp>/). Idempotent.
set -u
PROJ="${1:?usage: apply-project-masters.sh <project dir>}"
HERE="$(cd "$(dirname "$0")" && pwd)"
MANIFEST="$HERE/masters/MANIFEST.tsv"
[ -f "$MANIFEST" ] || { echo "no manifest at $MANIFEST — the team package is incomplete"; exit 2; }
[ -f "$PROJ/awsTutorial.uproject" ] || { echo "not a project dir: $PROJ"; exit 2; }
bash "$HERE/backup_step.sh" "$PROJ" masters || { echo "backup failed — nothing applied"; exit 1; }
n=0
while IFS=$'\t' read -r want master target; do
  [ -z "${want:-}" ] && continue; case "$want" in \#*) continue;; esac
  [ -f "$HERE/masters/$master" ] || { echo "master missing: $master"; exit 1; }
  mkdir -p "$(dirname "$PROJ/$target")"
  cp "$HERE/masters/$master" "$PROJ/$target" && n=$((n+1))
done < "$MANIFEST"
echo "copied $n files"
# Build.cs dependencies for the tuner (idempotent; re-copies the four tuner files with the module's line endings).
bash "$HERE/masters/graphics-autotune/apply_autotune_src.sh" "$PROJ" | tail -3
bash "$HERE/verify-project-masters.sh" "$PROJ"
