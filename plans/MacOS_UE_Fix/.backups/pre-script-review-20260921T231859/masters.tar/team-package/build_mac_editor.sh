#!/bin/bash
# build_mac_editor.sh - ON THE MAC. Builds the awsTutorial EDITOR target (SOP §8d / §11h-3 L2: the cook
# runs as the editor). Survives SSH disconnects; log /tmp/evc_build_mac_editor.log (ends with BUILD_EXIT=).
# Paths: UE_ENGINE and UE_PROJECT_DIR in the environment override the Air's defaults; UE_PARALLEL the action count.
ENGINE="${UE_ENGINE:-/Volumes/UnrealEngine/UE_5_4_1}"
PROJDIR="${UE_PROJECT_DIR:-/Volumes/UnrealEngine/Unreal_Projects/awsTutorial}"
UPROJECT="$PROJDIR/awsTutorial.uproject"
PARALLEL="${UE_PARALLEL:-6}"
LOG=/tmp/evc_build_mac_editor.log
: > "$LOG"
# Guard (2026-09-21): an editor built from an engine without patch 6g cooks and packages a game whose resolution list
# is wrong; refuse early. The check script lives beside this one (team package, or ~/gfx_autotune/ on the Air).
GUARD="$(cd "$(dirname "$0")" && pwd)/check_engine_patch.sh"
[ -f "$GUARD" ] || { echo "check_engine_patch.sh missing beside $0 — refusing to build" | tee -a "$LOG"; echo BUILD_EXIT=1 >> "$LOG"; exit 1; }
bash "$GUARD" "$ENGINE/Engine/Source/Runtime/Apple/MetalRHI/Private/MetalRHI.cpp" | tee -a "$LOG" || { echo BUILD_EXIT=1 >> "$LOG"; exit 1; }
nohup bash -c "cd '$ENGINE' && caffeinate -dimsu Engine/Build/BatchFiles/Mac/Build.sh awsTutorialEditor Mac Development -project='$UPROJECT' -MaxParallelActions=$PARALLEL >> '$LOG' 2>&1; echo BUILD_EXIT=\$? >> '$LOG'" </dev/null >/dev/null 2>&1 &
echo "started pid $! ; log $LOG"
