#!/bin/bash
# make-project-zip.sh [project dir] [out zip] — ON THE MAC that holds the current project (the Air today).
# Zips the project for run-ue541-mac.sh step 12: sources, content, config, plugins AND Build/ (the editor's "Zip Up
# Project" omits Build/ — SOP §8a·1), without intermediates, saved data, binaries, packaged apps, backups or
# AppleDouble sidecars. Checks first that the project carries the masters (verify-project-masters.sh) and the live
# lineage (SOP §8·0), and prints the zip's md5 and the same two checks read back from the zip.
# Defaults: /Volumes/UnrealEngine/Unreal_Projects/awsTutorial -> ~/Downloads/ue541-team-package/awsTutorial-src-<date>.zip
# Takes ~10 min for ~6 GB. Nothing in the project is modified.
set -u
PROJ="${1:-/Volumes/UnrealEngine/Unreal_Projects/awsTutorial}"
OUT="${2:-$HOME/Downloads/ue541-team-package/awsTutorial-src-$(date +%Y-%m-%d).zip}"
HERE="$(cd "$(dirname "$0")" && pwd)"
[ -f "$PROJ/awsTutorial.uproject" ] || { echo "not a project dir: $PROJ"; exit 2; }
echo "== masters check"; bash "$HERE/verify-project-masters.sh" "$PROJ" | tail -1 || { echo "project differs from the masters — apply them first (apply-project-masters.sh)"; exit 1; }
echo "== lineage check (SOP §8·0): BP_SC_CatPara + BP_WG_CatPara present, CAT_PARA family absent"
LIVE=$(find "$PROJ/Content" -name 'BP_SC_CatPara.uasset' -o -name 'BP_WG_CatPara.uasset' | wc -l | tr -d ' ')
FORK=$(find "$PROJ/Content" -name 'BP_SC_CAT_PARAOG.uasset' -o -name 'BP_WG_CAT_PARAOG.uasset' | wc -l | tr -d ' ')
echo "   live markers $LIVE (want 2), fork markers $FORK (want 0)"
[ "$LIVE" = 2 ] && [ "$FORK" = 0 ] || { echo "LINEAGE CHECK FAILED — this is not the live project"; exit 1; }
rm -f "$OUT"; mkdir -p "$(dirname "$OUT")"
echo "== zipping $PROJ -> $OUT ($(date +%T))"
( cd "$PROJ" && COPYFILE_DISABLE=1 zip -q -r -X "$OUT" awsTutorial.uproject Build Config Content Plugins Source \
    -x '*/Intermediate/*' '*/Binaries/*' '*/Saved/*' '*/DerivedDataCache/*' '*/.backups/*' '*/__pycache__/*' \
       '*.DS_Store' '._*' '*/._*' 'Build/Mac/Resources/.backups/*' ) || { echo "zip failed"; exit 1; }
echo "== $(du -h "$OUT" | cut -f1)  md5 $(md5 -q "$OUT")  ($(date +%T))"
echo "== read-back checks"
echo "   NoSandbox.entitlements: $(unzip -Z1 "$OUT" | grep -c 'Build/Mac/Resources/NoSandbox.entitlements') (want 1)"
echo "   Info.Template.plist mic key: $(unzip -p "$OUT" Build/Mac/Resources/Info.Template.plist | grep -c NSMicrophone) (want 1)"
echo "   Config/Mac/MacEngine.ini: $(unzip -Z1 "$OUT" | grep -c '^Config/Mac/MacEngine.ini$') (want 1)"
echo "   tuner sources: $(unzip -Z1 "$OUT" | grep -c 'Source/awsTutorial/GraphicsAutoTuneSubsystem') (want 2)"
echo "   lineage: $(unzip -Z1 "$OUT" | grep -cE 'BP_(SC|WG)_CatPara\.uasset') live (want 2), $(unzip -Z1 "$OUT" | grep -cE 'BP_(SC|WG)_CAT_PARAOG\.uasset') fork (want 0)"
echo "   Packaged/ or Saved/ leaked: $(unzip -Z1 "$OUT" | grep -cE '^(Packaged|Saved|Intermediate|Binaries)/') (want 0)"
md5 -q "$OUT" > "$OUT.md5"; echo "== done: $OUT (+ .md5)"
