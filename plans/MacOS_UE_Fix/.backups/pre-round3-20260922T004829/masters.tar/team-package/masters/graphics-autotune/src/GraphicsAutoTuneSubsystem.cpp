// First-launch graphics auto-tuning (2026-09-18). See GraphicsAutoTuneSubsystem.h for the design.

#include "GraphicsAutoTuneSubsystem.h"

#include "Blueprint/UserWidget.h"
#include "Components/ActorComponent.h"
#include "DynamicRHI.h"
#include "Engine/Engine.h"
#include "Engine/GameInstance.h"
#include "Engine/GameViewportClient.h"
#include "Engine/World.h"
#include "Framework/Application/SlateApplication.h"
#include "GameFramework/Pawn.h"
#include "GameFramework/GameUserSettings.h"
#include "GameFramework/PlayerController.h"
#include "GameFramework/SaveGame.h"
#include "HAL/IConsoleManager.h"
#include "Kismet/GameplayStatics.h"
#include "Kismet/KismetSystemLibrary.h"
#include "Misc/App.h"
#include "Misc/CommandLine.h"
#include "Misc/ConfigCacheIni.h"
#include "Misc/DateTime.h"
#include "PipelineStateCache.h"
#include "RenderTimer.h"
#include "ShaderPipelineCache.h"
#include "Styling/CoreStyle.h"
#include "UObject/EnumProperty.h"
#include "UObject/UObjectGlobals.h"
#include "UObject/UnrealType.h"
#include "Widgets/Layout/SBorder.h"
#include "Widgets/SBoxPanel.h"
#include "Widgets/SWindow.h"
#include "Widgets/Text/STextBlock.h"

#if PLATFORM_WINDOWS
#include "Windows/WindowsHWrapper.h"
#endif
#if PLATFORM_MAC
#include "MacDisplayInsets.h"
#endif

DEFINE_LOG_CATEGORY(LogGraphicsAutoTune);

static TAutoConsoleVariable<int32> CVarGraphicsAutoTuneEnable(
    TEXT("gfx.AutoTune.Enable"),
    1,
    TEXT("1 = tune graphics automatically on the first launch (default). 0 = never tune; a run in progress is cancelled and the previous settings restored."),
    ECVF_Default);

static TAutoConsoleVariable<float> CVarGraphicsAutoTuneTestBudgetScale(
    TEXT("gfx.AutoTune.TestBudgetScale"),
    1.0f,
    TEXT("TESTING ONLY: multiplies the 60/30 fps frame budgets (e.g. 0.6 makes a fast GPU take the lower-resolution path). Default 1."),
    ECVF_Cheat);

static TAutoConsoleVariable<int32> CVarMacWindowRepair(
    TEXT("gfx.MacWindowRepair"),
    3,
    TEXT("macOS only, and it is what keeps clicks under the pointer. 0 = leave the window alone. 1 = always a windowed window the width of the usable display, under the menu bar and above the Dock (insets read from the OS; gfx.MacMenuBarPx/MacTitleBarPx/MacDockPx override). 2 = always fullscreen at the display height less gfx.MacFullscreenTrim. 3 (default) = follow the options menu's screen-mode row: Windowed as 1, Fullscreen or Windowed Fullscreen as 2 - but only after a correct windowed window has been held, never straight from launch."),
    ECVF_Default);

static TAutoConsoleVariable<int32> CVarMacFullscreenTrim(
    TEXT("gfx.MacFullscreenTrim"),
    0,
    TEXT("macOS, fullscreen targets of gfx.MacWindowRepair 2/3: pixels taken off the display height for fullscreen. 0 (default) = the menu bar's height as the OS reports it (68 on a 2880x1864 Air, 66 on a 3024x1964 Pro); a positive value replaces it (74 was the hand-measured value on the Air before it was read from the OS)."),
    ECVF_Default);

// The three windowed-mode insets are read from AppKit at run time (Mac/MacDisplayInsets.mm: NSScreen frame vs
// visibleFrame, NSWindow's frame-for-content arithmetic) since 2026-09-21 - the lab MacBook Pro's Dock is 146 px where
// the Air's is 120, and its menu bar 66 where the Air's is 68, so measured constants left the game's bottom edge under
// the Dock. The engine's own FDisplayMetrics cannot supply them: PrimaryDisplayWorkAreaRect on macOS puts Cocoa's
// bottom-left visibleFrame origin (the Dock's height) in Top. These cvars are overrides now: 0 = use the measured value
// (the measured values are logged as "macOS insets" at the first repair); a positive value replaces it.
static TAutoConsoleVariable<int32> CVarMacMenuBarPx(
    TEXT("gfx.MacMenuBarPx"),
    0,
    TEXT("macOS, gfx.MacWindowRepair 1: height of the menu bar in pixels. 0 (default) = read from the OS (68 on a 2880x1864 MacBook Air with a camera housing, 66 on a 3024x1964 MacBook Pro). The window's title bar starts under it."),
    ECVF_Default);

static TAutoConsoleVariable<int32> CVarMacTitleBarPx(
    TEXT("gfx.MacTitleBarPx"),
    0,
    TEXT("macOS, gfx.MacWindowRepair 1: height of the window's own title bar in pixels. 0 (default) = read from the OS (56 = the standard 28 pt at 2x). r.setres sizes the content below it and the window is placed by its content, so this is where the content starts."),
    ECVF_Default);

static TAutoConsoleVariable<int32> CVarMacDockPx(
    TEXT("gfx.MacDockPx"),
    0,
    TEXT("macOS, gfx.MacWindowRepair 1: height in pixels kept clear at the bottom of the display for the Dock, so the video player's controls are not behind it. 0 (default) = read from the OS (120 on the Air's default Dock, 146 on the lab MacBook Pro's; the OS reports 0 when the Dock is hidden or on a side)."),
    ECVF_Default);

namespace GfxAutoTune
{
    // Bump when the ladder or thresholds change enough that installs tuned by an older version should be re-tuned.
    // 2 (2026-09-19): the resolution row is now chosen for the display rather than looked up from the viewport the
    // game already happens to be in. Installs tuned by version 1 kept whatever resolution the menu defaulted to —
    // 1280x800 on a Retina Mac — so they have to be tuned again for the fix to reach them.
    // 3 (2026-09-21): one profile per power source (AC / battery); the keys carry the profile name as a suffix, so
    // every install measures again — which macOS needs anyway, occlusion culling having been switched off there.
    // 4, macOS only (2026-09-21): steps are scored by real drawing time (see FinishStep) — every Mac measured by 3 in
    // a windowed window read 33.3 ms at every rung and chose the highest one; they have to measure again. Windows
    // installs are unaffected and stay at 3.
    // 5, macOS only (2026-09-21 evening): the ladder's "native" resolution scale is the panel's, not the virtual
    // framebuffer's (NativePercent) - a 13.6" Air in its factory scaled mode drew 32% more pixels than it has - and the
    // Resolution row is no longer set on macOS (the repair owns the geometry). Macs measure again once.
#if PLATFORM_MAC
    constexpr int32 TuneVersion = 5;
#else
    constexpr int32 TuneVersion = 3;
#endif
    // macOS: a windowed frame that overruns a refresh interval waits for the next one, so the wall-clock frame time
    // sits on 16.7/33.3/50 ms whatever the settings. When it exceeds the real drawing time by this much, the real time
    // is what the ladder scores.
    constexpr float DisplaySyncSlackMs = 3.0f;
    constexpr int32 MaxAttempts = 3;              // cancelled runs (per profile) before giving up (the menu defaults stay)
    constexpr double PowerPollSeconds = 2.0;      // how often the power source is read
    constexpr double PowerDebounceSeconds = 5.0;  // a change must persist this long (docks and chargers flap briefly)
    constexpr int32 BatteryStartRung = 1;         // Medium: the most the battery profile ever uses
    // Runs that measured to the end but could not be applied (a menu row failed) or saved, before the install is marked
    // tuned anyway. Without this bound a deterministic failure - a row renamed by a menu update, a save directory that
    // cannot be written - re-tunes at every launch for ever: three launches with the overlay, one skipped, repeat.
    constexpr int32 MaxFinishedFailures = 3;
    constexpr double MacWindowStartDelaySeconds = 3.0; // leave the window alone while the game is still coming up
    // Used only if AppKit reports no screens: a menu bar without a camera housing and the standard title bar, in
    // points, times the window's backing scale (no Dock assumed).
    constexpr float MacFallbackMenuBarPt = 25.f;
    constexpr float MacFallbackTitleBarPt = 28.f;
    constexpr double MacFullscreenAfterSeconds = 2.0; // a correct windowed window must have been held this long before a fullscreen target is enforced
    constexpr double MacWindowSettleSeconds = 1.0;     // the window must be wrong for this long before it is corrected (transitions animate)
    constexpr double MacWindowRetrySeconds = 2.0;      // between two r.setres from the repair
    constexpr int32 MacWindowMaxFailures = 3;          // corrections in a row that did not take, before it stops until something changes
    constexpr int32 MacWindowTolerancePx = 4;          // size/position slack: Cocoa points round to pixels
    constexpr double MenuWaitTimeoutSeconds = 600.0; // the options menu only exists after the login screen, so be generous

    const TCHAR* const ConfigSection = TEXT("GraphicsAutoTune");
    const TCHAR* const MenuSlotName = TEXT("/Settings/MyOptions");   // AntizeMenuSystem BP_MainMenuFunction.GetSlotNameUserIndex
    const TCHAR* const MenuComponentClassName = TEXT("BP_MainMenuComponent_C");

    // "Stable" = 95th-percentile frame cost within 90 % of the frame budget.
    constexpr float Budget60BaseMs = 15.0f;
    constexpr float Budget30BaseMs = 30.0f;
    float BudgetScale() { return FMath::Clamp(CVarGraphicsAutoTuneTestBudgetScale.GetValueOnGameThread(), 0.1f, 1.0f); }
    float Budget60Ms() { return Budget60BaseMs * BudgetScale(); }
    float Budget30Ms() { return Budget30BaseMs * BudgetScale(); }

    constexpr double MenuGraceSeconds = 1.5;      // rows (incl. key-binding rows) finish loading ~0.2 s after the menu is built
    constexpr double LevelGraceSeconds = 5.0;
    constexpr double MaxShaderWaitSeconds = 60.0; // stop waiting for shader/PSO precompiles after this
    constexpr double SettleSeconds = 2.0;
    constexpr double MaxExtraSettleSeconds = 8.0; // extra wait for precompiles triggered by a new candidate
    constexpr double SampleSeconds = 5.0;
    constexpr double MaxSampleSeconds = 15.0;
    constexpr int32 MinFrames = 30;
    constexpr double RunTimeoutSeconds = 300.0;   // on timeout the best result measured so far is kept
    constexpr double PollSeconds = 0.5;

    constexpr int32 MinScreenPercent = 50;
    constexpr float NoGainTolerance = 1.05f;      // a rung within 5 % of Low's frame time gains nothing from going lower
    constexpr float MinResolutionGain = 0.97f;    // keep lowering the resolution while a step cuts the p95 frame time by >= 3 %
    constexpr int32 MaxResolutionSteps = 6;

    // Options-menu rows the tuner changes per quality rung (menu option indices: High, Medium, Low).
    struct FTunableRow
    {
        const TCHAR* Name;
        int32 Index[3];
    };
    const FTunableRow TunableRows[] =
    {
        { TEXT("Graphic_Texture"),      { 2, 1, 0 } },  // Low, Medium, High, Very High, Epic
        { TEXT("Graphic_Anisotropy"),   { 3, 2, 1 } },  // Off, 4x, 8x, 16x
        { TEXT("Graphic_PostProcess"),  { 2, 1, 0 } },
        { TEXT("Graphic_AntiAliasing"), { 3, 2, 1 } },  // Off, Low, Medium, High, ... (kept on for temporal upscaling)
        { TEXT("Graphic_Effect"),       { 2, 1, 0 } },
        { TEXT("Graphic_DetailMode"),   { 2, 1, 0 } },  // Low, Medium, High
        { TEXT("Graphic_Foliage"),      { 2, 1, 0 } },
        { TEXT("Graphic_ViewDistance"), { 2, 1, 0 } },
        { TEXT("Graphic_Shaders"),      { 2, 1, 0 } },
        { TEXT("Graphic_Reflections"),  { 2, 1, 0 } },
    };
    const TCHAR* const RungNames[3] = { TEXT("High"), TEXT("Medium"), TEXT("Low") };

    // Rows held at the operator's defaults on every machine.
    struct FFixedRow
    {
        const TCHAR* Name;
        int32 Index;
    };
    const FFixedRow FixedRows[] =
    {
        { TEXT("Graphic_Shadow"), 1 },              // Low (sg.ShadowQuality 0)
        { TEXT("Graphic_GlobalIllumination"), 0 },  // Low (no Lumen, no distance-field AO)
        { TEXT("Graphic_MotionBlur"), 0 },          // Off
        { TEXT("Graphic_VSync"), 1 },               // Enabled
    };

    const TCHAR* const MaxFpsRow = TEXT("Graphic_MaxFPS");     // 15, 30, 60, 120, 144, Unlimited
    const int32 MaxFpsValues[] = { 15, 30, 60, 120, 144, 999 }; // the row's t.MaxFPS commands
    constexpr int32 MaxFps30Index = 1;
    constexpr int32 MaxFps60Index = 2;
    const TCHAR* const VSyncRow = TEXT("Graphic_VSync");
    const TCHAR* const ScreenModeRow = TEXT("Graphic_ScreenMode");  // Windowed, Windowed Fullscreen, Fullscreen
    constexpr int32 WindowedIndex = 0;
    constexpr int32 WindowedFullscreenIndex = 1;
    const TCHAR* const ResolutionRow = TEXT("Graphic_Resolution");
    const TCHAR* const ScreenScaleRow = TEXT("Graphic_ScreenScale");

    // True when running on battery power. FWindowsPlatformMisc::IsRunningOnBattery (5.4) tests the battery's charge
    // flag instead of the AC line, so it reports "battery" for any plugged-in laptop whose battery is charged; ask
    // Windows for the AC line directly. The macOS implementation (IOPowerSources state) is correct.
    bool IsOnBatteryPower()
    {
#if PLATFORM_WINDOWS
        SYSTEM_POWER_STATUS Status;
        return ::GetSystemPowerStatus(&Status) && Status.ACLineStatus == 0; // 0 offline, 1 online, 255 unknown
#else
        return FPlatformMisc::IsRunningOnBattery();
#endif
    }

    float Percentile(TArray<float> Values, float Fraction)
    {
        if (Values.Num() == 0)
        {
            return 0.f;
        }
        Values.Sort();
        const int32 Index = FMath::Clamp(FMath::CeilToInt(Fraction * Values.Num()) - 1, 0, Values.Num() - 1);
        return Values[Index];
    }
    float Percentile95(const TArray<float>& Values) { return Percentile(Values, 0.95f); }

    // A step whose typical frame is well inside the budget but whose 95th percentile is not was most likely hit by
    // one-time hitches (first-launch shader/pipeline compilation); it is measured once more before it counts.
    constexpr float HitchMedianFraction = 0.85f;

    // Calls a Blueprint function/event by name. SetParams fills the parameter buffer (return false to cancel the
    // call); ReadParams reads out-parameters after the call.
    bool CallFunction(UObject* Target, const TCHAR* FunctionName,
                      TFunctionRef<bool(UFunction*, uint8*)> SetParams,
                      TFunctionRef<void(UFunction*, uint8*)> ReadParams)
    {
        UFunction* Function = Target ? Target->FindFunction(FName(FunctionName)) : nullptr;
        if (!Function)
        {
            UE_LOG(LogGraphicsAutoTune, Warning, TEXT("%s has no function %s"), *GetNameSafe(Target), FunctionName);
            return false;
        }
        if (Function->ParmsSize == 0)
        {
            Target->ProcessEvent(Function, nullptr);
            return true;
        }
        uint8* Parms = static_cast<uint8*>(FMemory_Alloca_Aligned(Function->ParmsSize, Function->GetMinAlignment()));
        FMemory::Memzero(Parms, Function->ParmsSize);
        for (TFieldIterator<FProperty> It(Function); It && It->HasAnyPropertyFlags(CPF_Parm); ++It)
        {
            It->InitializeValue_InContainer(Parms);
        }
        const bool bParamsOk = SetParams(Function, Parms);
        if (bParamsOk)
        {
            Target->ProcessEvent(Function, Parms);
            ReadParams(Function, Parms);
        }
        else
        {
            UE_LOG(LogGraphicsAutoTune, Warning, TEXT("%s.%s: unexpected parameters"), *GetNameSafe(Target), FunctionName);
        }
        for (TFieldIterator<FProperty> It(Function); It && It->HasAnyPropertyFlags(CPF_Parm); ++It)
        {
            It->DestroyValue_InContainer(Parms);
        }
        return bParamsOk;
    }

    bool CallNoParams(UObject* Target, const TCHAR* FunctionName)
    {
        return CallFunction(Target, FunctionName, [](UFunction*, uint8*) { return true; }, [](UFunction*, uint8*) {});
    }

    bool CallWithInt(UObject* Target, const TCHAR* FunctionName, const TCHAR* ParamName, int32 Value)
    {
        return CallFunction(Target, FunctionName,
            [ParamName, Value](UFunction* Function, uint8* Parms)
            {
                FIntProperty* Param = CastField<FIntProperty>(Function->FindPropertyByName(FName(ParamName)));
                if (!Param)
                {
                    return false;
                }
                Param->SetPropertyValue_InContainer(Parms, Value);
                return true;
            },
            [](UFunction*, uint8*) {});
    }

    bool CallWithDouble(UObject* Target, const TCHAR* FunctionName, const TCHAR* ParamName, double Value)
    {
        return CallFunction(Target, FunctionName,
            [ParamName, Value](UFunction* Function, uint8* Parms)
            {
                FProperty* Param = Function->FindPropertyByName(FName(ParamName));
                if (FDoubleProperty* AsDouble = CastField<FDoubleProperty>(Param))
                {
                    AsDouble->SetPropertyValue_InContainer(Parms, Value);
                    return true;
                }
                if (FFloatProperty* AsFloat = CastField<FFloatProperty>(Param))
                {
                    AsFloat->SetPropertyValue_InContainer(Parms, static_cast<float>(Value));
                    return true;
                }
                return false;
            },
            [](UFunction*, uint8*) {});
    }

    // W_Options.SaveOptions(out bool Success?) - only a fallback (it also marks the key bindings as saved).
    bool CallSaveOptions(UObject* Menu, bool& bOutSuccess)
    {
        bOutSuccess = false;
        return CallFunction(Menu, TEXT("SaveOptions"),
            [](UFunction*, uint8*) { return true; },
            [&bOutSuccess](UFunction* Function, uint8* Parms)
            {
                if (FBoolProperty* Result = CastField<FBoolProperty>(Function->FindPropertyByName(FName(TEXT("Success?")))))
                {
                    bOutSuccess = Result->GetPropertyValue_InContainer(Parms);
                }
            });
    }

    UObject* GetObjectProperty(const UObject* Owner, const TCHAR* PropertyName)
    {
        if (!Owner)
        {
            return nullptr;
        }
        FObjectPropertyBase* Property = FindFProperty<FObjectPropertyBase>(Owner->GetClass(), FName(PropertyName));
        return Property ? Property->GetObjectPropertyValue_InContainer(Owner) : nullptr;
    }

    int32 GetIntProperty(const UObject* Owner, const TCHAR* PropertyName, int32 Default)
    {
        const FIntProperty* Property = Owner ? FindFProperty<FIntProperty>(Owner->GetClass(), FName(PropertyName)) : nullptr;
        return Property ? Property->GetPropertyValue_InContainer(Owner) : Default;
    }

    // Reads a byte or enum property (e.g. a row's TEnumAsByte<E_TemplateGraphic> SettingName).
    int32 GetByteProperty(const UObject* Owner, const TCHAR* PropertyName, int32 Default)
    {
        const FProperty* Property = Owner ? FindFProperty<FProperty>(Owner->GetClass(), FName(PropertyName)) : nullptr;
        if (const FByteProperty* AsByte = CastField<FByteProperty>(Property))
        {
            return AsByte->GetPropertyValue_InContainer(Owner);
        }
        if (const FEnumProperty* AsEnum = CastField<FEnumProperty>(Property))
        {
            return static_cast<int32>(AsEnum->GetUnderlyingProperty()->GetSignedIntPropertyValue(AsEnum->ContainerPtrToValuePtr<void>(Owner)));
        }
        return Default;
    }

    double GetDoubleProperty(const UObject* Owner, const TCHAR* PropertyName, double Default)
    {
        const FProperty* Property = Owner ? FindFProperty<FProperty>(Owner->GetClass(), FName(PropertyName)) : nullptr;
        if (const FDoubleProperty* AsDouble = CastField<FDoubleProperty>(Property))
        {
            return AsDouble->GetPropertyValue_InContainer(Owner);
        }
        if (const FFloatProperty* AsFloat = CastField<FFloatProperty>(Property))
        {
            return AsFloat->GetPropertyValue_InContainer(Owner);
        }
        return Default;
    }

    FString GetStringProperty(const UObject* Owner, const TCHAR* PropertyName)
    {
        const FStrProperty* Property = Owner ? FindFProperty<FStrProperty>(Owner->GetClass(), FName(PropertyName)) : nullptr;
        return Property ? Property->GetPropertyValue_InContainer(Owner) : FString();
    }

    // Display strings of a row's ButtonOptions (TArray<FText>).
    TArray<FString> GetButtonOptions(const UObject* Row)
    {
        TArray<FString> Out;
        const FArrayProperty* Property = Row ? FindFProperty<FArrayProperty>(Row->GetClass(), FName(TEXT("ButtonOptions"))) : nullptr;
        const FTextProperty* Inner = Property ? CastField<FTextProperty>(Property->Inner) : nullptr;
        if (!Inner)
        {
            return Out;
        }
        FScriptArrayHelper Helper(Property, Property->ContainerPtrToValuePtr<void>(Row));
        for (int32 Index = 0; Index < Helper.Num(); ++Index)
        {
            Out.Add(Inner->GetPropertyValue(Helper.GetRawPtr(Index)).ToString());
        }
        return Out;
    }

    // Sets W_Options.MyGraphicIndex[SettingIndex].Index (the menu's per-setting value string, indexed by E_TemplateGraphic).
    bool SetMenuGraphicValue(UObject* Menu, int32 SettingIndex, const FString& Value)
    {
        FArrayProperty* Property = Menu ? FindFProperty<FArrayProperty>(Menu->GetClass(), FName(TEXT("MyGraphicIndex"))) : nullptr;
        FStructProperty* Inner = Property ? CastField<FStructProperty>(Property->Inner) : nullptr;
        FStrProperty* Field = nullptr;
        if (Inner)
        {
            for (TFieldIterator<FStrProperty> It(Inner->Struct); It; ++It)
            {
                Field = *It;   // S_GraphicIndex has a single string member ("Index")
                break;
            }
        }
        if (!Field || SettingIndex < 0 || SettingIndex > 64)
        {
            return false;
        }
        FScriptArrayHelper Helper(Property, Property->ContainerPtrToValuePtr<void>(Menu));
        if (SettingIndex >= Helper.Num())
        {
            Helper.AddValues(SettingIndex + 1 - Helper.Num());
        }
        Field->SetPropertyValue_InContainer(Helper.GetRawPtr(SettingIndex), Value);
        return true;
    }
}

bool UGraphicsAutoTuneSubsystem::ShouldCreateSubsystem(UObject* Outer) const
{
    return !IsRunningDedicatedServer() && Super::ShouldCreateSubsystem(Outer);
}

void UGraphicsAutoTuneSubsystem::Initialize(FSubsystemCollectionBase& Collection)
{
    Super::Initialize(Collection);

#if PLATFORM_MAC
    // Every macOS launch starts windowed (operator decision 2026-09-21). The engine creates its window after the game
    // instance's subsystems initialize (UGameEngine::Init: InitializeStandalone, then CreateGameWindow), so the saved
    // mode can still be corrected here. A window created fullscreen renders into the corner with dead input and an
    // unattended launch hangs in the transition; the options menu re-applies its own mode after login and
    // RepairMacWindow then makes that mode correct (gfx.MacWindowRepair 3).
    if (!GIsEditor && CVarMacWindowRepair.GetValueOnGameThread() != 0)
    {
        if (UGameUserSettings* Settings = GEngine ? GEngine->GetGameUserSettings() : nullptr)
        {
            if (Settings->GetFullscreenMode() != EWindowMode::Windowed)
            {
                const int32 Saved = static_cast<int32>(Settings->GetFullscreenMode());
                Settings->SetFullscreenMode(EWindowMode::Windowed);
                Settings->ConfirmVideoMode();
                Settings->SaveSettings();
                UE_LOG(LogGraphicsAutoTune, Display, TEXT("macOS: the saved window mode was %d; the window is created Windowed and the options menu decides after login"), Saved);
                RecordTrace(FString::Printf(TEXT("startup mode forced Windowed (saved %d)"), Saved));
            }
        }
    }
#endif

    LevelStartTime = FPlatformTime::Seconds();
    TickHandle = FTSTicker::GetCoreTicker().AddTicker(FTickerDelegate::CreateUObject(this, &UGraphicsAutoTuneSubsystem::Tick));
    PostLoadMapHandle = FCoreUObjectDelegates::PostLoadMapWithWorld.AddUObject(this, &UGraphicsAutoTuneSubsystem::OnPostLoadMap);
    if (!IConsoleManager::Get().FindConsoleObject(TEXT("gfx.AutoTune.Run")))
    {
        RunCommand = IConsoleManager::Get().RegisterConsoleCommand(
            TEXT("gfx.AutoTune.Run"),
            TEXT("Re-run the graphics auto-tuner in the current level (the result is saved through the options menu)."),
            FConsoleCommandDelegate::CreateUObject(this, &UGraphicsAutoTuneSubsystem::RequestRun),
            ECVF_Default);
    }

    if (FParse::Param(FCommandLine::Get(), TEXT("NoGraphicsAutoTune")))
    {
        UE_LOG(LogGraphicsAutoTune, Display, TEXT("Disabled by -NoGraphicsAutoTune"));
        bDisabled = true;
        return;
    }
    bForced = FParse::Param(FCommandLine::Get(), TEXT("GraphicsAutoTune"));

#if WITH_EDITOR
    if (GIsEditor && !bForced)
    {
        bDisabled = true;
        return; // never tune play-in-editor sessions unless asked
    }
#endif

    // Pre-version-3 key: the battery deferral is gone (each power source has its own profile now).
    GConfig->RemoveKey(GfxAutoTune::ConfigSection, TEXT("BatteryDeferrals"), GGameUserSettingsIni);

    const EPowerProfile State = CurrentPowerProfile();
    LastPowerState = State;
    const bool bHasMenuSave = UGameplayStatics::DoesSaveGameExist(GfxAutoTune::MenuSlotName, 0);
    const bool bTuned = IsProfileTuned(State);
    const int32 Attempts = ProfileGetInt(State, TEXT("Attempts"));
    const int32 FinishedFailures = ReadFinishedFailures(State);

    // Any profile this version has not measured yet. It deliberately does NOT care whether an options save already
    // exists: a Shipping build saves to the user directory (FApp::IsInstalled), which on any machine that has run an
    // earlier build already holds one — and reading that as "the player chose these settings" is what stopped
    // Shipping builds ever benchmarking. TunedVersion<profile>, written when a run finishes, keeps this to once per
    // power source.
    if (!bForced && !bTuned && FinishedFailures >= GfxAutoTune::MaxFinishedFailures)
    {
        // Runs that finished but could not be applied or saved. Commit marks the profile tuned on the third; this
        // repeats the check so a crash between Commit's two writes cannot leave the install retrying for ever.
        UE_LOG(LogGraphicsAutoTune, Warning, TEXT("Not tuning the %s profile any more: %d runs finished but could not be applied or saved (see LastResult%s); the menu's settings stay"),
            ProfileName(State), FinishedFailures, ProfileName(State));
        RecordOutcome(State, FString::Printf(TEXT("stood down for good: %d runs finished but could not be applied or saved; the menu's settings stay"), FinishedFailures), true);
        bPending = false;
    }
    else if (!bForced && !bTuned && Attempts >= GfxAutoTune::MaxAttempts)
    {
        UE_LOG(LogGraphicsAutoTune, Warning, TEXT("Not tuning the %s profile this launch: %d runs in a row were cancelled; the menu's settings stay"), ProfileName(State), Attempts);
        // Not marked finished, and the count is cleared: the next launch is free to try again rather than this
        // profile being disabled for good.
        RecordOutcome(State, FString::Printf(TEXT("stood down after %d cancelled runs; will try again next launch"), Attempts), false);
        ProfileSetInt(State, TEXT("Attempts"), 0);
        GConfig->Flush(false, GGameUserSettingsIni);
        bPending = false;
    }
    else
    {
        bPending = bForced || !bTuned;
    }
    UE_LOG(LogGraphicsAutoTune, Display, TEXT("Startup on %s power: AC profile %s, battery profile %s%s; %s (options save %s%s)"),
        State == EPowerProfile::Battery ? TEXT("battery") : TEXT("AC"),
        IsProfileTuned(EPowerProfile::AC) ? TEXT("measured") : TEXT("not measured"),
        IsProfileTuned(EPowerProfile::Battery) ? TEXT("measured") : TEXT("not measured"),
        ProfileGetInt(EPowerProfile::Battery, TEXT("Provisional")) ? TEXT(" (provisional, derived from AC)") : TEXT(""),
        bPending ? TEXT("will measure it in the first level with the options menu") : TEXT("no measurement needed"),
        bHasMenuSave ? TEXT("present") : TEXT("absent"), bForced ? TEXT(", forced by -GraphicsAutoTune") : TEXT(""));
    RecordTrace(FString::Printf(TEXT("startup on %s: AC %s, battery %s, %s"), ProfileName(State),
        IsProfileTuned(EPowerProfile::AC) ? TEXT("measured") : TEXT("unmeasured"),
        IsProfileTuned(EPowerProfile::Battery) ? TEXT("measured") : TEXT("unmeasured"),
        bPending ? TEXT("will measure") : TEXT("nothing to measure")));
    // Always through the menu: even with nothing to measure, the menu may hold the other power source's profile.
    Phase = EPhase::WaitForMenu;
}

void UGraphicsAutoTuneSubsystem::Deinitialize()
{
    EndRun();
    FTSTicker::GetCoreTicker().RemoveTicker(TickHandle);
    FCoreUObjectDelegates::PostLoadMapWithWorld.Remove(PostLoadMapHandle);
    if (RunCommand)
    {
        IConsoleManager::Get().UnregisterConsoleObject(RunCommand);
        RunCommand = nullptr;
    }
    Phase = EPhase::Idle;
    Super::Deinitialize();
}

void UGraphicsAutoTuneSubsystem::RequestRun()
{
    if (IsTuning())
    {
        UE_LOG(LogGraphicsAutoTune, Display, TEXT("A tuning pass is already running"));
        return;
    }
    UE_LOG(LogGraphicsAutoTune, Display, TEXT("Tuning requested"));
    bPending = true;
    bForced = true;
    Menu.Reset();
    NextPollTime = 0.0;
    Phase = EPhase::WaitForMenu;
}

bool UGraphicsAutoTuneSubsystem::IsTuning() const
{
    return Phase == EPhase::Settling || Phase == EPhase::Sampling;
}

void UGraphicsAutoTuneSubsystem::OnPostLoadMap(UWorld* LoadedWorld)
{
    LevelStartTime = FPlatformTime::Seconds();
    if (IsTuning())
    {
        Abort(TEXT("the level changed"), false);
    }
    Menu.Reset();
    if (bPending)
    {
        NextPollTime = 0.0;
        Phase = EPhase::WaitForMenu;
    }
}

UUserWidget* UGraphicsAutoTuneSubsystem::FindMenu(APawn*& OutPawn, APlayerController*& OutPC) const
{
    OutPawn = nullptr;
    OutPC = nullptr;
    UGameInstance* GameInstance = GetGameInstance();
    APlayerController* PC = GameInstance ? GameInstance->GetFirstLocalPlayerController() : nullptr;
    APawn* Pawn = PC ? PC->GetPawn() : nullptr;
    if (!Pawn)
    {
        return nullptr;
    }
    for (UActorComponent* Component : Pawn->GetComponents())
    {
        if (Component && Component->GetClass()->GetName() == GfxAutoTune::MenuComponentClassName)
        {
            UUserWidget* Found = Cast<UUserWidget>(GfxAutoTune::GetObjectProperty(Component, TEXT("W_OptionsRef")));
            if (Found && Found->IsInViewport())
            {
                OutPawn = Pawn;
                OutPC = PC;
                return Found;
            }
        }
    }
    return nullptr;
}

bool UGraphicsAutoTuneSubsystem::IsMenuOpen() const
{
    return Menu.IsValid() && Menu->IsVisible();
}

bool UGraphicsAutoTuneSubsystem::IsShaderWorkPending() const
{
    return PipelineStateCache::NumActivePrecacheRequests() > 0 || FShaderPipelineCache::NumPrecompilesRemaining() > 0;
}

bool UGraphicsAutoTuneSubsystem::IsWindowMinimized() const
{
    UGameViewportClient* Viewport = GetGameInstance() ? GetGameInstance()->GetGameViewportClient() : nullptr;
    const TSharedPtr<SWindow> Window = Viewport ? Viewport->GetWindow() : nullptr;
    return Window.IsValid() && Window->IsWindowMinimized();
}

bool UGraphicsAutoTuneSubsystem::Tick(float DeltaTime)
{
    const double Now = FPlatformTime::Seconds();
    RepairMacWindow(Now);           // macOS input repair; runs whether or not this session is tuning

    if (CVarGraphicsAutoTuneEnable.GetValueOnGameThread() == 0)
    {
        if (IsTuning())
        {
            Abort(TEXT("it was disabled with gfx.AutoTune.Enable 0"), true);
        }
        return true;
    }
    UpdatePowerState(Now);          // plug/unplug: switch profiles, or cancel a run and re-arm

    if (Phase == EPhase::Idle)
    {
        return true;
    }

    switch (Phase)
    {
    case EPhase::WaitForMenu:
    {
        if (Now < NextPollTime)
        {
            break;
        }
        NextPollTime = Now + GfxAutoTune::PollSeconds;
        APawn* Pawn = nullptr;
        APlayerController* PC = nullptr;
        if (UUserWidget* Found = FindMenu(Pawn, PC))
        {
            Menu = Found;
            TunedPawn = Pawn;
            TunedController = PC;
            MenuFoundTime = Now;
            Phase = EPhase::WaitForSettle;
            UE_LOG(LogGraphicsAutoTune, Display, TEXT("Options menu found; waiting for the level to settle"));
            RecordTrace(FString::Printf(TEXT("menu found %.0f s after level start; waiting to settle (shader work %s)"),
                Now - LevelStartTime, IsShaderWorkPending() ? TEXT("pending") : TEXT("done")));
        }
        else if (LevelStartTime > 0.0 && Now - LevelStartTime > GfxAutoTune::MenuWaitTimeoutSeconds)
        {
            // Without this the wait is silent and endless, and in a Shipping build there is no log to show it.
            UE_LOG(LogGraphicsAutoTune, Warning, TEXT("No options menu after %.0f s in this level; not tuning here"),
                GfxAutoTune::MenuWaitTimeoutSeconds);
            RecordOutcome(LastPowerState, TEXT("skipped: no options menu found in the level"), false);
            Phase = EPhase::Idle;
        }
        break;
    }
    case EPhase::WaitForSettle:
    {
        if (Now < NextPollTime)
        {
            break;
        }
        NextPollTime = Now + GfxAutoTune::PollSeconds;
        APawn* Pawn = nullptr;
        APlayerController* PC = nullptr;
        if (!Menu.IsValid() || FindMenu(Pawn, PC) != Menu.Get())
        {
            Menu.Reset();
            Phase = EPhase::WaitForMenu;
            break;
        }
        // (An options save existing is no longer a reason to skip — see the gate in Initialize. Opening the options
        // menu during a run still aborts it, which is the case that actually means "the player is choosing".)
        const bool bMenuSettled = Now - MenuFoundTime >= GfxAutoTune::MenuGraceSeconds;
        const bool bLevelSettled = Now - LevelStartTime >= GfxAutoTune::LevelGraceSeconds;
        const bool bShadersSettled = !IsShaderWorkPending() || Now - MenuFoundTime >= GfxAutoTune::MaxShaderWaitSeconds;
        if (bMenuSettled && bLevelSettled && bShadersSettled && !IsMenuOpen() && !IsWindowMinimized())
        {
            // The menu has re-applied its save slot by now; make sure it holds the profile for the current power
            // source (the stored one, or the provisional battery one) before anything else.
            RecordTrace(FString::Printf(TEXT("settled %.0f s after the menu was found (shader wait %s); %s"), Now - MenuFoundTime,
                IsShaderWorkPending() ? TEXT("timed out") : TEXT("done"), bPending ? TEXT("starting the measurement") : TEXT("nothing to measure")));
            ReconcileAppliedProfile(LastPowerState);
            if (!bPending)
            {
                Phase = EPhase::Idle;
                break;
            }
            BeginRun(LastPowerState);
        }
        break;
    }
    case EPhase::Settling:
    case EPhase::Sampling:
    {
        if (!Menu.IsValid() || !TunedPawn.IsValid() || (TunedController.IsValid() && TunedController->GetPawn() != TunedPawn.Get()))
        {
            Abort(TEXT("the level or the player's pawn changed"), Menu.IsValid());
            break;
        }
        if (IsMenuOpen())
        {
            Abort(TEXT("the options menu was opened"), true);
            break;
        }
        if (Now - RunStartTime > GfxAutoTune::RunTimeoutSeconds)
        {
            UE_LOG(LogGraphicsAutoTune, Warning, TEXT("Tuning is taking too long; keeping the best result measured so far"));
            CommitBestSoFar();
            break;
        }
        if (IsWindowMinimized())
        {
            StartSettling(); // nothing is rendered while minimized; measure this candidate again afterwards
            break;
        }
        const double Elapsed = Now - PhaseStartTime;
        if (Phase == EPhase::Settling)
        {
            const bool bShadersSettled = !IsShaderWorkPending() || Elapsed >= GfxAutoTune::SettleSeconds + GfxAutoTune::MaxExtraSettleSeconds;
            if (Elapsed >= GfxAutoTune::SettleSeconds && bShadersSettled)
            {
                Phase = EPhase::Sampling;
                PhaseStartTime = Now;
            }
        }
        else
        {
            AddSample();
            if ((Elapsed >= GfxAutoTune::SampleSeconds && CostSamples.Num() >= GfxAutoTune::MinFrames) || Elapsed >= GfxAutoTune::MaxSampleSeconds)
            {
                FinishStep();
            }
        }
        break;
    }
    default:
        break;
    }
    return true;
}

void UGraphicsAutoTuneSubsystem::BeginRun(EPowerProfile Which)
{
    CurrentProfile = Which;
    UUserWidget* MenuWidget = Menu.Get();
    UObject* ProbeRow = MenuWidget ? MenuWidget->GetWidgetFromName(FName(GfxAutoTune::TunableRows[0].Name)) : nullptr;
    if (!ProbeRow || !ProbeRow->FindFunction(FName(TEXT("ByGlobalSetting"))) || !MenuWidget->FindFunction(FName(TEXT("MakeBackUp"))))
    {
        UE_LOG(LogGraphicsAutoTune, Error, TEXT("The options menu does not have the expected rows/functions; auto-tuning disabled for this session"));
        RecordOutcome(Which, TEXT("skipped: the options menu lacks the expected rows"), false);
        bPending = false;
        Phase = EPhase::Idle;
        return;
    }

    const int32 Attempts = ProfileGetInt(Which, TEXT("Attempts"));
    if (!bForced && Attempts >= GfxAutoTune::MaxAttempts)
    {
        UE_LOG(LogGraphicsAutoTune, Warning, TEXT("Not tuning the %s profile this launch: %d runs in a row were cancelled; the menu's settings stay"), ProfileName(Which), Attempts);
        RecordOutcome(Which, FString::Printf(TEXT("stood down after %d cancelled runs; will try again next launch"), Attempts), false);
        ProfileSetInt(Which, TEXT("Attempts"), 0);
        GConfig->Flush(false, GGameUserSettingsIni);
        bPending = false;
        Phase = EPhase::Idle;
        return;
    }
    ProfileSetInt(Which, TEXT("Attempts"), Attempts + 1);
    GConfig->Flush(false, GGameUserSettingsIni);

    OriginalRowIndex.Reset();
    auto Remember = [this](const TCHAR* RowName)
    {
        const int32 Index = GetRowIndex(RowName);
        if (Index >= 0)
        {
            OriginalRowIndex.Add(RowName, Index);
        }
    };
    for (const GfxAutoTune::FTunableRow& Row : GfxAutoTune::TunableRows)
    {
        Remember(Row.Name);
    }
    for (const GfxAutoTune::FFixedRow& Row : GfxAutoTune::FixedRows)
    {
        Remember(Row.Name);
    }
    Remember(GfxAutoTune::MaxFpsRow);
    Remember(GfxAutoTune::ScreenModeRow);
    Remember(GfxAutoTune::ResolutionRow);
    OriginalScreenPercent = GfxAutoTune::GetDoubleProperty(MenuWidget->GetWidgetFromName(FName(GfxAutoTune::ScreenScaleRow)), TEXT("SliderValue"), 100.0);

    // Console commands that undo the run's frame-cap/V-Sync changes if it is cut short after the menu is gone.
    const int32* OriginalFps = OriginalRowIndex.Find(GfxAutoTune::MaxFpsRow);
    RestoreFrameCapCommand = (OriginalFps && *OriginalFps >= 0 && *OriginalFps < static_cast<int32>(UE_ARRAY_COUNT(GfxAutoTune::MaxFpsValues)))
        ? FString::Printf(TEXT("t.MaxFPS %d"), GfxAutoTune::MaxFpsValues[*OriginalFps]) : FString();
    const int32* OriginalVSync = OriginalRowIndex.Find(GfxAutoTune::VSyncRow);
    RestoreVSyncCommand = OriginalVSync ? FString::Printf(TEXT("r.VSync %d"), *OriginalVSync != 0 ? 1 : 0) : FString();

    Results.Reset();
    ResolutionSteps = 0;
    bRemeasured = false;
    bScreenPercentTouched = false;
    bGpuTimingAvailable = true;
    RunStartTime = FPlatformTime::Seconds();

    FVector2D ViewportSize(0, 0);
    if (UGameViewportClient* Viewport = GetGameInstance()->GetGameViewportClient())
    {
        Viewport->GetViewportSize(ViewportSize);
    }
    UE_LOG(LogGraphicsAutoTune, Display, TEXT("Tuning started for the %s profile, attempt %d (viewport %dx%d, resolution scale %.0f%%, budgets %.1f/%.1f ms)"),
        ProfileName(Which), Attempts + 1, static_cast<int32>(ViewportSize.X), static_cast<int32>(ViewportSize.Y), OriginalScreenPercent,
        GfxAutoTune::Budget60Ms(), GfxAutoTune::Budget30Ms());

    SetGameplayInputBlocked(true);
    ShowOverlay(Which);

    // Windowed fullscreen at the display's resolution and the operator's fixed rows. Then V-Sync and the frame cap go
    // off for the measurement (behind the overlay): with them on, the render thread's time includes waiting for the
    // display (measured 15-16 ms on every rung of an RTX 5070 whose GPU needed 7 ms), and a 30 fps cap lets
    // integrated GPUs clock down. Commit applies V-Sync and the chosen cap through the menu; aborts restore them.
#if !PLATFORM_MAC
    // On macOS the window is RepairMacWindow's business: the measurement runs in the windowed, native-density window
    // it has put in place, and the two mode rows are set at commit only. Changing them here would start a fullscreen
    // transition in the middle of the measurement.
    SetRowIfDifferent(GfxAutoTune::ScreenModeRow, GfxAutoTune::WindowedFullscreenIndex);
    const int32 ResolutionIndex = FindDisplayResolutionIndex();
    if (ResolutionIndex >= 0)
    {
        SetRowIfDifferent(GfxAutoTune::ResolutionRow, ResolutionIndex);
    }
#endif
    for (const GfxAutoTune::FFixedRow& Row : GfxAutoTune::FixedRows)
    {
        SetRow(Row.Name, Row.Index);
    }
    ExecConsole(TEXT("r.VSync 0"));
    ExecConsole(TEXT("t.MaxFPS 0"));
    // "Native" for the ladder is the panel's pixel count. On macOS a scaled display mode draws a virtual framebuffer
    // larger than the panel (a 13.6" Air's factory 1470x956 mode: 2940x1912 onto 2560x1664, 1.15x per axis), and
    // those pixels are resampled away by the window server; measuring and committing them costs GPU time for nothing.
    // The cap is the panel-to-virtual ratio per axis, rounded down to 5 %, never below the floor.
    NativePercent = 100;
#if PLATFORM_MAC
    if (MacPanelVirtualOverPanel > 1.02f)
    {
        NativePercent = FMath::Clamp(FMath::FloorToInt(100.f / MacPanelVirtualOverPanel / 5.f) * 5, GfxAutoTune::MinScreenPercent, 100);
        UE_LOG(LogGraphicsAutoTune, Display, TEXT("macOS: the display mode is scaled (%.2fx the panel per axis); the ladder's native resolution scale is %d%%"), MacPanelVirtualOverPanel, NativePercent);
        RecordTrace(FString::Printf(TEXT("scaled mode %.2fx: native scale %d%%"), MacPanelVirtualOverPanel, NativePercent));
    }
#endif
    // The battery ladder never goes above Medium; the AC ladder starts at High.
    ApplyCandidate(Which == EPowerProfile::Battery ? GfxAutoTune::BatteryStartRung : 0, NativePercent);
    StartSettling();
}

void UGraphicsAutoTuneSubsystem::ApplyCandidate(int32 Rung, int32 ScreenPercent)
{
    CurrentRung = Rung;
    CurrentScreenPercent = ScreenPercent;
    for (const GfxAutoTune::FTunableRow& Row : GfxAutoTune::TunableRows)
    {
        SetRow(Row.Name, Row.Index[Rung]);
    }
    if (bScreenPercentTouched || FMath::Abs(OriginalScreenPercent - ScreenPercent) > 0.5)
    {
        // Trial only; the menu's Resolution Scale row is set once, at commit.
        ExecConsole(FString::Printf(TEXT("r.ScreenPercentage %d"), ScreenPercent));
        bScreenPercentTouched = true;
    }
    UpdateOverlay();
}

void UGraphicsAutoTuneSubsystem::StartSettling()
{
    CostSamples.Reset();
    CpuSamples.Reset();
    GameSamples.Reset();
    RenderSamples.Reset();
    RhiSamples.Reset();
    GpuSamples.Reset();
    Phase = EPhase::Settling;
    PhaseStartTime = FPlatformTime::Seconds();
}

void UGraphicsAutoTuneSubsystem::AddSample()
{
    // The cost is the real frame time, measured uncapped with V-Sync off. The per-thread and GPU times are kept to
    // tell GPU-bound from CPU-bound and for the log.
    const float FrameMs = static_cast<float>(FApp::GetDeltaTime() * 1000.0);
    const float GameMs = FPlatformTime::ToMilliseconds(GGameThreadTime);
    const float RenderMs = FPlatformTime::ToMilliseconds(GRenderThreadTime);
    const float RhiMs = FPlatformTime::ToMilliseconds(GRHIThreadTime);
    const float GpuMs = FPlatformTime::ToMilliseconds(RHIGetGPUFrameCycles(0));
    GameSamples.Add(GameMs);
    RenderSamples.Add(RenderMs);
    RhiSamples.Add(RhiMs);
    GpuSamples.Add(GpuMs);
    CpuSamples.Add(FMath::Max(GameMs, RenderMs));
    CostSamples.Add(FrameMs);
}

void UGraphicsAutoTuneSubsystem::FinishStep()
{
    using namespace GfxAutoTune;

    FStepResult Result;
    Result.Rung = CurrentRung;
    Result.ScreenPercent = CurrentScreenPercent;
    Result.Frames = CostSamples.Num();
    Result.CostP95 = Percentile95(CostSamples);
    Result.CostP50 = Percentile(CostSamples, 0.5f);
    Result.CpuP95 = Percentile95(CpuSamples);
    Result.GameP95 = Percentile95(GameSamples);
    Result.RenderP95 = Percentile95(RenderSamples);
    Result.RhiP95 = Percentile95(RhiSamples);
    Result.GpuP95 = Percentile95(GpuSamples);

    if (Result.GpuP95 <= 0.f)
    {
        if (bGpuTimingAvailable)
        {
            UE_LOG(LogGraphicsAutoTune, Warning, TEXT("This GPU/driver reports no GPU timing; treating the frame time as GPU time"));
        }
        bGpuTimingAvailable = false;
        Result.GpuP95 = Result.CostP95;
    }
    Result.WallP95 = Result.CostP95;
#if PLATFORM_MAC
    // In a windowed macOS window the frame is shown only at a display refresh, and r.VSync 0 does not lift that: a
    // frame that draws in 21 ms and one that draws in 29 ms both read 33.3 ms. Measured 2026-09-21 on a 2880x1864 Air:
    // High/Medium/Low all 34 ms wall while the GPU took 29/27/21 ms — every rung looked equal and the ladder kept the
    // highest. Score by the real drawing time instead: the longer of the GPU and the busiest CPU thread, the time the
    // frame would take without the refresh lock. The wall time stays in the log.
    if (bGpuTimingAvailable)
    {
        const float RealP95 = FMath::Max(Result.GpuP95, Result.CpuP95);
        const float RealP50 = FMath::Max(Percentile(GpuSamples, 0.5f), Percentile(CpuSamples, 0.5f));
        if (Result.WallP95 > RealP95 + DisplaySyncSlackMs)
        {
            UE_LOG(LogGraphicsAutoTune, Display, TEXT("%s at %d%%: wall-clock p95 %.1f ms is display-synced (GPU %.1f, CPU %.1f); scoring the real drawing time %.1f ms"),
                RungNames[Result.Rung], Result.ScreenPercent, Result.WallP95, Result.GpuP95, Result.CpuP95, RealP95);
        }
        Result.CostP95 = RealP95;
        Result.CostP50 = RealP50;
    }
#endif

    // The battery profile targets 30 fps only; the AC profile tries 60 first at native resolution.
    const bool bAllow60 = CurrentProfile == EPowerProfile::AC;
    const float StepBudget = (ResolutionSteps == 0 && bAllow60) ? Budget60Ms() : Budget30Ms();
    if (!bRemeasured && Result.CostP95 > StepBudget && Result.CostP50 <= HitchMedianFraction * StepBudget)
    {
        UE_LOG(LogGraphicsAutoTune, Display, TEXT("%s at %d%%: median %.1f ms but p95 %.1f ms - hitches (likely first-time shader compilation); measuring again"),
            RungNames[Result.Rung], Result.ScreenPercent, Result.CostP50, Result.CostP95);
        bRemeasured = true;
        StartSettling();
        return;
    }
    bRemeasured = false;

    Results.Add(Result);
    UE_LOG(LogGraphicsAutoTune, Display, TEXT("Step %d: %s at %d%% -> p95 cost %.1f ms, median %.1f (wall %.1f; p95 game %.1f, render %.1f, RHI %.1f, GPU %.1f) over %d frames"),
        Results.Num(), RungNames[Result.Rung], Result.ScreenPercent, Result.CostP95, Result.CostP50, Result.WallP95, Result.GameP95, Result.RenderP95, Result.RhiP95, Result.GpuP95, Result.Frames);

    if (ResolutionSteps == 0)
    {
        // Quality ladder at native resolution: AC, the first rung that holds 60 wins; battery, the first that holds 30.
        if (bAllow60 && Result.CostP95 <= Budget60Ms())
        {
            Commit(Result.Rung, 60, NativePercent);
            return;
        }
        if (!bAllow60 && Result.CostP95 <= Budget30Ms())
        {
            Commit(Result.Rung, 30, NativePercent);
            return;
        }
        if (Result.Rung < 2)
        {
            ApplyCandidate(Result.Rung + 1, NativePercent);
            StartSettling();
            return;
        }
        // Low misses 60: keep the highest rung that holds 30 (results are in High, Medium, Low order). On battery
        // nothing held 30, so this finds nothing and the resolution logic below decides.
        for (const FStepResult& Earlier : Results)
        {
            if (Earlier.ScreenPercent == NativePercent && Earlier.CostP95 <= Budget30Ms())
            {
                Commit(Earlier.Rung, 30, NativePercent);
                return;
            }
        }
        // Lowering the resolution only helps if the GPU itself misses the budget. The GPU time is the deciding number:
        // the render/RHI threads can block on the GPU without that being counted as idle (seen on an AMD 780M and on
        // Metal), so they can look busy when the GPU is the real limit.
        if (Result.GpuP95 <= Budget30Ms())
        {
            // Not GPU-limited: the CPU (or an outside limit such as a laptop's battery frame cap) sets the frame rate,
            // so neither a lower resolution nor lower settings help. Keep the highest rung that is not materially
            // slower than Low.
            int32 KeepRung = 2;
            for (const FStepResult& Earlier : Results)
            {
                if (Earlier.ScreenPercent == NativePercent && Earlier.CostP95 <= Result.CostP95 * NoGainTolerance)
                {
                    KeepRung = Earlier.Rung;
                    break;
                }
            }
            UE_LOG(LogGraphicsAutoTune, Warning, TEXT("30 fps not reached even at Low, but the GPU is within budget (%.1f ms): the limit is the CPU or an outside frame cap, so lower settings or resolution would not help; keeping %s at native resolution"),
                Result.GpuP95, RungNames[KeepRung]);
            Commit(KeepRung, 30, NativePercent);
            return;
        }
        // GPU-bound at Low: estimate the resolution scale from pixel-count scaling (relative to the scale just
        // measured), then verify.
        const float Estimate = NativePercent * FMath::Sqrt(Budget30Ms() / FMath::Max(Result.GpuP95, 1.f));
        const int32 Percent = FMath::Clamp(FMath::FloorToInt(Estimate / 5.f) * 5, MinScreenPercent, FMath::Max(MinScreenPercent, NativePercent - 5));
        ResolutionSteps = 1;
        ApplyCandidate(2, Percent);
        StartSettling();
        return;
    }

    // Lowering the resolution percentage at Low, 30 fps target.
    if (Result.CostP95 <= Budget30Ms())
    {
        Commit(2, 30, Result.ScreenPercent);
        return;
    }
    // Stop when the floor is reached, or when the last step no longer helped and the GPU is within budget (then the
    // CPU is the limit). The GPU number alone is not enough: the render thread can wait on the GPU without that
    // counting as idle, so it keeps the frame over budget until the GPU has real headroom.
    const FStepResult& Previous = Results[Results.Num() - 2];
    const bool bStillHelping = Result.CostP95 < Previous.CostP95 * MinResolutionGain;
    if (Result.ScreenPercent <= MinScreenPercent || ResolutionSteps >= MaxResolutionSteps || (!bStillHelping && Result.GpuP95 <= Budget30Ms()))
    {
        UE_LOG(LogGraphicsAutoTune, Warning, TEXT("Below minimum spec: 30 fps not reached at %d%% resolution (%s); keeping the lowest settings"),
            Result.ScreenPercent, Result.ScreenPercent <= MinScreenPercent || ResolutionSteps >= MaxResolutionSteps
                ? TEXT("resolution floor reached")
                : TEXT("a lower resolution stopped helping, so the CPU is the limit"));
        Commit(2, 30, Result.ScreenPercent);
        return;
    }
    ++ResolutionSteps;
    ApplyCandidate(2, FMath::Max(MinScreenPercent, Result.ScreenPercent - 10));
    StartSettling();
}

void UGraphicsAutoTuneSubsystem::CommitBestSoFar()
{
    if (Results.Num() == 0)
    {
        Abort(TEXT("nothing could be measured in time"), true);
        return;
    }
    for (const FStepResult& Step : Results)
    {
        if (CurrentProfile == EPowerProfile::AC && Step.ScreenPercent == NativePercent && Step.CostP95 <= GfxAutoTune::Budget60Ms())
        {
            Commit(Step.Rung, 60, NativePercent);
            return;
        }
    }
    for (const FStepResult& Step : Results)
    {
        if (Step.ScreenPercent == NativePercent && Step.CostP95 <= GfxAutoTune::Budget30Ms())
        {
            Commit(Step.Rung, 30, NativePercent);
            return;
        }
    }
    int32 LowestPercent = NativePercent;
    for (const FStepResult& Step : Results)
    {
        LowestPercent = FMath::Min(LowestPercent, Step.ScreenPercent);
    }
    Commit(2, 30, LowestPercent);
}

bool UGraphicsAutoTuneSubsystem::ApplyProfile(EPowerProfile Which, const FProfile& Settings, bool bForceScreenPercent, bool& bOutSaved)
{
    UUserWidget* MenuWidget = Menu.Get();
    bOutSaved = false;
    if (!MenuWidget)
    {
        return false;
    }
    // Every row has to take. A run whose rows did not apply is not recorded as tuned (it would otherwise leave a
    // profile marked tuned with nothing applied, never to tune again); it is tuned again at the next launch, like a
    // run whose save failed.
    const int32 Rung = FMath::Clamp(Settings.Rung, 0, 2);
    bool bApplied = true;
    for (const GfxAutoTune::FTunableRow& Row : GfxAutoTune::TunableRows)
    {
        bApplied &= SetRow(Row.Name, Row.Index[Rung]);
    }
    for (const GfxAutoTune::FFixedRow& Row : GfxAutoTune::FixedRows)
    {
        bApplied &= SetRow(Row.Name, Row.Index); // includes V-Sync On (switched off for the measurement)
    }
    bApplied &= SetRow(GfxAutoTune::MaxFpsRow, Settings.Fps >= 60 ? GfxAutoTune::MaxFps60Index : GfxAutoTune::MaxFps30Index);
#if PLATFORM_MAC
    // Windowed is the one mode whose hit test is right from launch on macOS (see RepairMacWindow, which sizes and
    // places the window); saving it keeps the menu and the window in agreement at the next launch.
    const int32 ScreenModeIndex = GfxAutoTune::WindowedIndex;
#else
    const int32 ScreenModeIndex = GfxAutoTune::WindowedFullscreenIndex;
#endif
    bApplied &= SetRowIfDifferent(GfxAutoTune::ScreenModeRow, ScreenModeIndex);
#if !PLATFORM_MAC
    // On macOS the Resolution row is left alone: RepairMacWindow owns the window's size, and the row's list mixes
    // units there (HiDPI modes in points, 1x modes in pixels), so a "display" entry can ask for a window larger than
    // the screen. Setting it also made the window flicker at commit (review M5/M7).
    const int32 ResolutionIndex = FindDisplayResolutionIndex();
    if (ResolutionIndex >= 0)
    {
        bApplied &= SetRowIfDifferent(GfxAutoTune::ResolutionRow, ResolutionIndex);
    }
#endif
    // The Resolution Scale row: set when the slider differs, or when a run changed r.ScreenPercentage behind it.
    const double SliderNow = GfxAutoTune::GetDoubleProperty(MenuWidget->GetWidgetFromName(FName(GfxAutoTune::ScreenScaleRow)), TEXT("SliderValue"), 100.0);
    if (bForceScreenPercent || FMath::Abs(SliderNow - Settings.Percent) > 0.5)
    {
        if (!SetScreenPercentRow(Settings.Percent))
        {
            UE_LOG(LogGraphicsAutoTune, Warning, TEXT("Could not set the menu's Resolution Scale row; applying %d%% for this session only"), Settings.Percent);
            ExecConsole(FString::Printf(TEXT("r.ScreenPercentage %d"), Settings.Percent));
        }
    }

    // The per-row values no longer match a preset: show the Global Graphics row as "Custom".
    GfxAutoTune::CallNoParams(GfxAutoTune::GetObjectProperty(MenuWidget, TEXT("Widget_GlobalRef")), TEXT("GraphicsEdited"));

    bOutSaved = WriteGraphicsSave();
    if (!bOutSaved)
    {
        UE_LOG(LogGraphicsAutoTune, Warning, TEXT("Could not write the graphics settings directly; saving through the options menu instead"));
        GfxAutoTune::CallSaveOptions(MenuWidget, bOutSaved);
    }
    // Make the values the menu's "Cancel" point (clears its unsaved-changes state).
    GfxAutoTune::CallNoParams(MenuWidget, TEXT("MakeBackUp"));

    GConfig->SetString(GfxAutoTune::ConfigSection, TEXT("Applied"), ProfileName(Which), GGameUserSettingsIni);
    GConfig->Flush(false, GGameUserSettingsIni);
    return bApplied;
}

void UGraphicsAutoTuneSubsystem::ReconcileAppliedProfile(EPowerProfile Which)
{
    FProfile Settings;
    if (!ReadProfile(Which, Settings))
    {
        return; // nothing stored for this power source yet (a run will follow if one is pending)
    }
    FString Applied;
    GConfig->GetString(GfxAutoTune::ConfigSection, TEXT("Applied"), Applied, GGameUserSettingsIni);
    if (Applied == ProfileName(Which))
    {
        return;
    }
    bool bSaved = false;
    const bool bApplied = ApplyProfile(Which, Settings, false, bSaved);
    RecordTrace(FString::Printf(TEXT("applied the %s profile (%d,%d,%d) rows %s save %s"), ProfileName(Which), Settings.Rung, Settings.Fps, Settings.Percent,
        bApplied ? TEXT("ok") : TEXT("FAILED"), bSaved ? TEXT("ok") : TEXT("FAILED")));
    UE_LOG(LogGraphicsAutoTune, Display, TEXT("Applied the %s profile%s: %s, %d fps, %d%% resolution (rows %s, save %s)"),
        ProfileName(Which), (Which == EPowerProfile::Battery && ProfileGetInt(Which, TEXT("Provisional"))) ? TEXT(" (provisional, derived from AC)") : TEXT(""),
        GfxAutoTune::RungNames[FMath::Clamp(Settings.Rung, 0, 2)], Settings.Fps, Settings.Percent,
        bApplied ? TEXT("applied") : TEXT("NOT ALL APPLIED"), bSaved ? TEXT("written") : TEXT("FAILED"));
}

void UGraphicsAutoTuneSubsystem::UpdatePowerState(double Now)
{
    if (bDisabled || Now < NextPowerPollTime)
    {
        return;
    }
    NextPowerPollTime = Now + GfxAutoTune::PowerPollSeconds;
    const EPowerProfile State = CurrentPowerProfile();
    if (State == LastPowerState)
    {
        PowerChangeSince = 0.0;
        return;
    }
    if (PowerChangeSince <= 0.0)
    {
        PowerChangeSince = Now;
        return;
    }
    if (Now - PowerChangeSince < GfxAutoTune::PowerDebounceSeconds)
    {
        return;
    }
    PowerChangeSince = 0.0;
    LastPowerState = State;
    UE_LOG(LogGraphicsAutoTune, Display, TEXT("Power source changed: now on %s"), State == EPowerProfile::Battery ? TEXT("battery") : TEXT("AC"));
    RecordTrace(FString::Printf(TEXT("power source changed: now %s (%s)"), ProfileName(State), IsProfileTuned(State) ? TEXT("profile measured, switching") : TEXT("profile unmeasured, will measure")));
    if (IsTuning())
    {
        Abort(TEXT("the power source changed"), true); // restores the rows; recorded against the profile being measured
    }
    // Measure the new state's profile if it has none; otherwise just switch to it. Either way the WaitForMenu ->
    // WaitForSettle path does it, a couple of seconds from now, with the menu closed.
    const bool bTuned = IsProfileTuned(State);
    bPending = bForced || (!bTuned
        && ReadFinishedFailures(State) < GfxAutoTune::MaxFinishedFailures
        && ProfileGetInt(State, TEXT("Attempts")) < GfxAutoTune::MaxAttempts);
    NextPollTime = 0.0;
    Phase = EPhase::WaitForMenu;
}

void UGraphicsAutoTuneSubsystem::Commit(int32 Rung, int32 TargetFps, int32 ScreenPercent)
{
    const EPowerProfile Which = CurrentProfile;
    const FProfile Settings{ Rung, TargetFps, ScreenPercent };
    bool bSaved = false;
    const bool bApplied = ApplyProfile(Which, Settings, bScreenPercentTouched, bSaved);

    const FString Summary = FString::Printf(TEXT("%s profile: %s, %d fps, %d%% resolution"), ProfileName(Which), GfxAutoTune::RungNames[Rung], TargetFps, ScreenPercent);
    FString Steps;
    for (const FStepResult& Step : Results)
    {
        Steps += FString::Printf(TEXT("%s%s@%d%%=%.1fms(wall %.1f game %.1f render %.1f rhi %.1f gpu %.1f)"), Steps.IsEmpty() ? TEXT("") : TEXT("; "),
            GfxAutoTune::RungNames[Step.Rung], Step.ScreenPercent, Step.CostP95, Step.WallP95, Step.GameP95, Step.RenderP95, Step.RhiP95, Step.GpuP95);
    }
    ProfileSetString(Which, TEXT("LastSteps"), Steps);
    const bool bDone = bApplied && bSaved;
    if (bDone)
    {
        WriteProfile(Which, Settings);
        WriteFinishedFailures(Which, 0);
        if (Which == EPowerProfile::AC && !IsProfileTuned(EPowerProfile::Battery))
        {
            // Until the battery profile is measured, use this result capped at Medium and 30 fps; the first launch
            // on battery measures the real thing.
            const FProfile Provisional{ FMath::Max(Rung, GfxAutoTune::BatteryStartRung), 30, ScreenPercent };
            WriteProfile(EPowerProfile::Battery, Provisional);
            ProfileSetInt(EPowerProfile::Battery, TEXT("Provisional"), 1);
            UE_LOG(LogGraphicsAutoTune, Display, TEXT("Provisional battery profile derived from the AC result: %s, 30 fps, %d%% (measured for real on the first launch on battery)"),
                GfxAutoTune::RungNames[Provisional.Rung], Provisional.Percent);
        }
        if (Which == EPowerProfile::Battery)
        {
            ProfileSetInt(EPowerProfile::Battery, TEXT("Provisional"), 0);
        }
        RecordOutcome(Which, Summary, true);
    }
    else
    {
        // Not recorded as tuned, so the next launch tunes again - but only MaxFinishedFailures times: a failure that
        // repeats is deterministic (a row the menu no longer has, a save path that cannot be written) and retrying
        // would cost the player the overlay at every launch for ever.
        const int32 FinishedFailures = ReadFinishedFailures(Which) + 1;
        WriteFinishedFailures(Which, FinishedFailures);
        const bool bGiveUp = FinishedFailures >= GfxAutoTune::MaxFinishedFailures;
        const FString Why = bSaved ? TEXT(" (NOT fully applied: an options-menu row could not be set") : TEXT(" (NOT saved");
        RecordOutcome(Which, Summary + Why + (bGiveUp
            ? FString::Printf(TEXT("; %d such runs in a row, so this profile is marked tuned and stops retrying)"), FinishedFailures)
            : FString::Printf(TEXT("; will tune again next launch, %d of %d)"), FinishedFailures, GfxAutoTune::MaxFinishedFailures)), bGiveUp);
    }

    UE_LOG(LogGraphicsAutoTune, Display, TEXT("Result: %s (rows %s, settings save %s) in %.0f s. Steps: %s"),
        *Summary, bApplied ? TEXT("applied") : TEXT("NOT ALL APPLIED"), bSaved ? TEXT("written") : TEXT("FAILED"),
        FPlatformTime::Seconds() - RunStartTime, *Steps);

    // Done for this session either way; an unsaved result is tuned again at the next launch (TunedVersion not written).
    bPending = false;
    bForced = false;
    EndRun();
    Phase = EPhase::Idle;
}

void UGraphicsAutoTuneSubsystem::Abort(const TCHAR* Reason, bool bRestoreSettings)
{
    UE_LOG(LogGraphicsAutoTune, Warning, TEXT("Tuning cancelled because %s; %s"), Reason,
        bRestoreSettings ? TEXT("previous settings restored, will try again next launch") : TEXT("will try again in the next level with the options menu"));
    if (bRestoreSettings && Menu.IsValid())
    {
        for (const TPair<FString, int32>& Original : OriginalRowIndex)
        {
            const bool bResizesWindow = Original.Key == GfxAutoTune::ScreenModeRow || Original.Key == GfxAutoTune::ResolutionRow;
            if (bResizesWindow)
            {
                SetRowIfDifferent(*Original.Key, Original.Value);
            }
            else
            {
                SetRow(*Original.Key, Original.Value);
            }
        }
        if (bScreenPercentTouched)
        {
            ExecConsole(FString::Printf(TEXT("r.ScreenPercentage %s"), *FString::SanitizeFloat(OriginalScreenPercent)));
        }
        // The restored values are the menu's saved/default ones: make them the menu's "Cancel" point again.
        GfxAutoTune::CallNoParams(Menu.Get(), TEXT("MakeBackUp"));
    }
    else
    {
        // The menu is gone (level change): undo what could matter in a level without it. Quality levels are
        // re-applied by the next level's menu.
        if (bScreenPercentTouched)
        {
            ExecConsole(FString::Printf(TEXT("r.ScreenPercentage %s"), *FString::SanitizeFloat(OriginalScreenPercent)));
        }
        if (!RestoreFrameCapCommand.IsEmpty())
        {
            ExecConsole(RestoreFrameCapCommand);
        }
        if (!RestoreVSyncCommand.IsEmpty())
        {
            ExecConsole(RestoreVSyncCommand);
        }
    }
    // Shipping writes no log, so the reason has to reach the ini for a cancelled run to be diagnosable at all.
    RecordOutcome(CurrentProfile, FString::Printf(TEXT("cancelled: %s"), Reason), false);
    EndRun();
    // Do not retry in this level (the player is busy); OnPostLoadMap re-arms a pending run.
    Phase = EPhase::Idle;
}

void UGraphicsAutoTuneSubsystem::EndRun()
{
    HideOverlay();
    SetGameplayInputBlocked(false);
    CostSamples.Reset();
    CpuSamples.Reset();
    GameSamples.Reset();
    RenderSamples.Reset();
    RhiSamples.Reset();
    GpuSamples.Reset();
}

void UGraphicsAutoTuneSubsystem::RepairMacWindow(double Now)
{
#if PLATFORM_MAC
    const int32 Mode = CVarMacWindowRepair.GetValueOnGameThread();
    if (Mode == 0 || GIsEditor)
    {
        return;
    }
    if (IsTuning())
    {
        return; // a mode change in the middle of a measurement would poison its frame times; the window is seen to afterwards
    }
    if (LevelStartTime <= 0.0 || Now - LevelStartTime < GfxAutoTune::MacWindowStartDelaySeconds)
    {
        return;
    }
    UGameViewportClient* Viewport = GetGameInstance() ? GetGameInstance()->GetGameViewportClient() : nullptr;
    const TSharedPtr<SWindow> Window = Viewport ? Viewport->GetWindow() : nullptr;
    if (!Window.IsValid() || Window->IsWindowMinimized())
    {
        return;
    }

    // The display the window is on and its insets, all from AppKit (Mac/MacDisplayInsets.mm), in that display's
    // backing pixels - Slate's screen space on macOS. Every Apple laptop goes through the same arithmetic because
    // nothing here is a constant: a 13.6" Air in its factory "scaled" mode (frame 1470x956 pt, 2940x1912 px drawn onto
    // a 2560x1664 panel), a 16" Pro at exact 2x, a side Dock, an auto-hidden menu bar or an external 1x display all
    // arrive as different numbers from the same calls (panel matrix, 2026-09-21). The engine's own primary-display
    // metrics and point-based fallbacks stand in only when AppKit reports no screens.
    const float Dpi = FMath::Max(1.f, Window->GetDPIScaleFactor());
    FMacDisplayInsetsPx Insets;
    const bool bHaveInsets = GetMacDisplayInsetsPx(Window->GetPositionInScreen(), Insets) && Insets.DisplayWidth > 0 && Insets.DisplayHeight > 0;
    if (!bHaveInsets)
    {
        FDisplayMetrics Metrics;
        FDisplayMetrics::RebuildDisplayMetrics(Metrics);
        Insets = FMacDisplayInsetsPx();
        Insets.DisplayWidth = Metrics.PrimaryDisplayWidth;
        Insets.DisplayHeight = Metrics.PrimaryDisplayHeight;
        Insets.BackingScale = Dpi;
        Insets.MenuBar = FMath::RoundToInt(GfxAutoTune::MacFallbackMenuBarPt * Dpi);
        Insets.TitleBar = FMath::RoundToInt(GfxAutoTune::MacFallbackTitleBarPt * Dpi);
    }
    const int32 DisplayWidth = Insets.DisplayWidth;
    const int32 DisplayHeight = Insets.DisplayHeight;
    if (DisplayWidth <= 0 || DisplayHeight <= 0)
    {
        return;
    }
    // A positive gfx.Mac*Px replaces the value read from the OS.
    const int32 MenuBarOverride = CVarMacMenuBarPx.GetValueOnGameThread();
    const int32 TitleBarOverride = CVarMacTitleBarPx.GetValueOnGameThread();
    const int32 DockOverride = CVarMacDockPx.GetValueOnGameThread();
    const int32 MenuBar = FMath::Clamp(MenuBarOverride > 0 ? MenuBarOverride : Insets.MenuBar, 0, DisplayHeight / 4);
    const int32 TitleBar = FMath::Clamp(TitleBarOverride > 0 ? TitleBarOverride : Insets.TitleBar, 0, DisplayHeight / 8);
    const int32 Dock = FMath::Clamp(DockOverride > 0 ? DockOverride : Insets.Dock, 0, DisplayHeight / 4);
    const int32 Left = FMath::Clamp(Insets.Left, 0, DisplayWidth / 4);
    const int32 Right = FMath::Clamp(Insets.Right, 0, DisplayWidth / 4);
    MacPanelVirtualOverPanel = Insets.VirtualOverPanel();
    const FString Signature = FString::Printf(TEXT("%s|%d/%d/%d|%s"), *Insets.Signature(), MenuBar, TitleBar, Dock, bHaveInsets ? TEXT("os") : TEXT("fallback"));
    if (Signature != MacInsetsSignature)
    {
        // Logged at the first repair and again whenever the display, its mode, the Dock or the menu bar changes.
        const bool bFirst = MacInsetsSignature.IsEmpty();
        MacInsetsSignature = Signature;
        UE_LOG(LogGraphicsAutoTune, Display, TEXT("macOS insets%s: display %dx%d at %d,%d (panel %dx%d, %.2fx virtual, scale %.0f); menu bar %d, title bar %d, Dock %d, left %d, right %d, notch %d px (%s)"),
            bFirst ? TEXT("") : TEXT(" changed"), DisplayWidth, DisplayHeight, Insets.OriginX, Insets.OriginY, Insets.PanelWidth, Insets.PanelHeight, Insets.VirtualOverPanel(), Insets.BackingScale,
            MenuBar, TitleBar, Dock, Left, Right, Insets.Notch,
            bHaveInsets ? TEXT("read from the OS; positive gfx.MacMenuBarPx/MacTitleBarPx/MacDockPx override") : TEXT("the OS gave no screens; point fallbacks x scale"));
        RecordTrace(FString::Printf(TEXT("insets%s menu=%d title=%d dock=%d left=%d right=%d notch=%d display=%dx%d panel=%dx%d %s"), bFirst ? TEXT("") : TEXT("-changed"),
            MenuBar, TitleBar, Dock, Left, Right, Insets.Notch, DisplayWidth, DisplayHeight, Insets.PanelWidth, Insets.PanelHeight, bHaveInsets ? TEXT("os") : TEXT("fallback")));
    }

    // Which mode is wanted. 1 = windowed always; 2 = trimmed fullscreen always; 3 (default since build 43) = follow
    // the mode the options menu APPLIED. The row's live selection is not read (operator, 2026-09-21 evening: the
    // window must not change until the student presses Apply); what Apply does is run the row's command, which
    // changes the window's mode - so a mode change the repair did not issue itself is the menu's decision:
    // Fullscreen or Windowed Fullscreen -> trimmed Fullscreen (WF itself can never be made correct on macOS: the
    // engine caches visibleFrame as the window size), Windowed -> windowed. The same path covers the menu re-applying
    // its saved mode after login. Fullscreen is never a session's first target: a window created fullscreen renders
    // into the corner with dead input (handoff 2026-09-20 §5.2); Initialize forces a windowed start, and a fullscreen
    // target is enforced from a windowed window only after that window has been correct for MacFullscreenAfterSeconds.
    const EWindowMode::Type WindowModeNow = Window->GetWindowMode();
    if (Mode == 3)
    {
        if (!bMacLastWindowModeKnown)
        {
            MacLastWindowMode = WindowModeNow;
            bMacLastWindowModeKnown = true;
        }
        else if (WindowModeNow != MacLastWindowMode)
        {
            if (bMacRepairModeChangePending && WindowModeNow == MacRepairPendingMode)
            {
                bMacRepairModeChangePending = false; // the repair's own transition landing
            }
            else
            {
                const bool bAppliedFullscreen = WindowModeNow != EWindowMode::Windowed;
                UE_LOG(LogGraphicsAutoTune, Display, TEXT("macOS: the window mode changed to %s outside the repair (the options menu applied it); following with %s"),
                    LexToString(WindowModeNow), bAppliedFullscreen ? TEXT("trimmed Fullscreen") : TEXT("the windowed target"));
                RecordMacWindow(FString::Printf(TEXT("menu applied %s; following"), LexToString(WindowModeNow)));
                bMacMenuWantsFullscreen = bAppliedFullscreen;
                bMacMenuModeKnown = true;
            }
            MacLastWindowMode = WindowModeNow;
        }
    }
    if (WindowModeNow != EWindowMode::Windowed)
    {
        MacWindowedReachedTime = 0.0; // the hold starts again once the window is windowed and right
    }
    const bool bWindowedHeld = MacWindowedReachedTime > 0.0 && Now - MacWindowedReachedTime >= GfxAutoTune::MacFullscreenAfterSeconds;
    const bool bWantFullscreen = Mode == 2 || (Mode == 3 && bMacMenuModeKnown && bMacMenuWantsFullscreen && (bWindowedHeld || WindowModeNow != EWindowMode::Windowed));

    EWindowMode::Type WantMode = EWindowMode::Windowed;
    FIntPoint WantSize(DisplayWidth, DisplayHeight);
    FIntPoint WantPos(Insets.OriginX, Insets.OriginY);
    if (bWantFullscreen)
    {
        // Fullscreen at the display height less the strip macOS keeps at the top - the menu bar's height as the OS
        // reports it (68 px on the 2880x1864 Air, 66 on the 3024x1964 Pro); gfx.MacFullscreenTrim overrides it. This is
        // the one fullscreen height at which Slate's hit test matches the picture (the engine's own metrics disagree
        // with the OS here); 2880x1790 measured correct on the Air before the value was read from the OS.
        WantMode = EWindowMode::Fullscreen;
        const int32 TrimOverride = CVarMacFullscreenTrim.GetValueOnGameThread();
        const int32 Trim = FMath::Clamp(TrimOverride > 0 ? TrimOverride : MenuBar, 0, DisplayHeight / 4);
        WantSize.Y = FMath::Max(480, DisplayHeight - Trim);
    }
    else
    {
        // Windowed: content under the menu bar and the window's own title bar, stopping above the Dock so the video
        // player's controls are not behind it, and clear of a Dock or Stage Manager strip on either side. r.setres
        // sizes the content; the position is the content's top-left (FMacWindow::MoveWindowTo and
        // FMacApplication::OnWindowDidMove both work in content coordinates).
        WantSize.X = FMath::Max(640, DisplayWidth - Left - Right);
        WantSize.Y = FMath::Max(480, DisplayHeight - MenuBar - TitleBar - Dock);
        WantPos.X += Left;
        WantPos.Y += MenuBar + TitleBar;
    }
    const FString Target = FString::Printf(TEXT("%dx%d%s at %d,%d"), WantSize.X, WantSize.Y,
        WantMode == EWindowMode::Fullscreen ? TEXT(" fullscreen") : TEXT(" windowed"), WantPos.X, WantPos.Y);
    if (Target != MacWindowTarget)
    {
        // A new target - a knob, the menu's mode row, the display or the Dock changed - gets a fresh budget.
        if (!MacWindowTarget.IsEmpty())
        {
            UE_LOG(LogGraphicsAutoTune, Display, TEXT("macOS: window target is now %s (was %s)"), *Target, *MacWindowTarget);
        }
        MacWindowTarget = Target;
        MacWindowFailures = 0;
        bMacWindowGaveUp = false;
        MacWindowWrongSince = 0.0;
    }

    // Where the window actually is, as Slate sees it (FMacApplication reports content size and position in pixels).
    const FVector2D Size = Window->GetSizeInScreen();
    const FVector2D Pos = Window->GetPositionInScreen();
    const int32 Tol = GfxAutoTune::MacWindowTolerancePx;
    const bool bModeOk = Window->GetWindowMode() == WantMode;
    const bool bSizeOk = FMath::Abs(FMath::RoundToInt(Size.X) - WantSize.X) <= Tol && FMath::Abs(FMath::RoundToInt(Size.Y) - WantSize.Y) <= Tol;
    const bool bPosOk = WantMode == EWindowMode::Fullscreen
        || (FMath::Abs(FMath::RoundToInt(Pos.X) - WantPos.X) <= Tol && FMath::Abs(FMath::RoundToInt(Pos.Y) - WantPos.Y) <= Tol);
    if (bModeOk && bSizeOk && bPosOk)
    {
        if (WantMode == EWindowMode::Windowed && MacWindowedReachedTime <= 0.0)
        {
            MacWindowedReachedTime = Now;
        }
        if (MacWindowWrongSince > 0.0)
        {
            UE_LOG(LogGraphicsAutoTune, Display, TEXT("macOS: window is %s; clicks land under the pointer at this size"), *Target);
            RecordMacWindow(FString::Printf(TEXT("reached %s after %d correction(s)"), *Target, MacWindowFailures));
            // Make the windowed size the one the engine creates the window in at the next launch (operator decision
            // 2026-09-21: launch windowed on macOS; Initialize also forces the mode). The fullscreen target is never
            // saved as a startup mode.
            if (WantMode == EWindowMode::Windowed)
            {
                if (UGameUserSettings* Settings = GEngine ? GEngine->GetGameUserSettings() : nullptr)
                {
                    if (Settings->GetFullscreenMode() != EWindowMode::Windowed || Settings->GetScreenResolution() != WantSize)
                    {
                        Settings->SetFullscreenMode(EWindowMode::Windowed);
                        Settings->SetScreenResolution(WantSize);
                        Settings->ConfirmVideoMode();
                        Settings->SaveSettings();
                        UE_LOG(LogGraphicsAutoTune, Display, TEXT("macOS: saved Windowed %dx%d as the startup mode"), WantSize.X, WantSize.Y);
                    }
                }
            }
        }
        MacWindowWrongSince = 0.0;
        MacWindowFailures = 0;
        bMacWindowGaveUp = false;
        return;
    }

    // Wrong. Give whatever transition may be under way a moment, then correct it - a resize first (the engine centres
    // a resized window, so the move comes on a later tick, once the size is right).
    if (MacWindowWrongSince <= 0.0)
    {
        MacWindowWrongSince = Now;
        return;
    }
    if (Now - MacWindowWrongSince < GfxAutoTune::MacWindowSettleSeconds)
    {
        return;
    }
    if (MacWindowFailures >= GfxAutoTune::MacWindowMaxFailures)
    {
        if (!bMacWindowGaveUp)
        {
            bMacWindowGaveUp = true;
            UE_LOG(LogGraphicsAutoTune, Warning, TEXT("macOS: %d corrections in a row did not take (window is %s %dx%d at %d,%d, wanted %s); leaving it alone until the window or a gfx.Mac* knob changes"),
                MacWindowFailures, LexToString(Window->GetWindowMode()), FMath::RoundToInt(Size.X), FMath::RoundToInt(Size.Y),
                FMath::RoundToInt(Pos.X), FMath::RoundToInt(Pos.Y), *Target);
            RecordMacWindow(FString::Printf(TEXT("gave up after %d corrections: window is %s %dx%d at %d,%d, wanted %s"),
                MacWindowFailures, LexToString(Window->GetWindowMode()), FMath::RoundToInt(Size.X), FMath::RoundToInt(Size.Y),
                FMath::RoundToInt(Pos.X), FMath::RoundToInt(Pos.Y), *Target));
        }
        return;
    }
    if (!bModeOk || !bSizeOk)
    {
        if (Now - MacWindowLastApply < GfxAutoTune::MacWindowRetrySeconds)
        {
            return;
        }
        const FString Command = FString::Printf(TEXT("r.setres %dx%d%s"), WantSize.X, WantSize.Y, WantMode == EWindowMode::Fullscreen ? TEXT("f") : TEXT("w"));
        UE_LOG(LogGraphicsAutoTune, Display, TEXT("macOS: display %dx%d; window is %s %dx%d at %d,%d, wanted %s; applying %s (%d of %d)"),
            DisplayWidth, DisplayHeight, LexToString(Window->GetWindowMode()), FMath::RoundToInt(Size.X), FMath::RoundToInt(Size.Y),
            FMath::RoundToInt(Pos.X), FMath::RoundToInt(Pos.Y), *Target, *Command, MacWindowFailures + 1, GfxAutoTune::MacWindowMaxFailures);
        if (!bModeOk)
        {
            // So the mode change this command produces is not mistaken for one the options menu applied.
            bMacRepairModeChangePending = true;
            MacRepairPendingMode = WantMode;
        }
        ExecConsole(Command);
        RecordMacWindow(FString::Printf(TEXT("applied %s (%d of %d); window was %s %dx%d at %d,%d"), *Command, MacWindowFailures + 1, GfxAutoTune::MacWindowMaxFailures,
            LexToString(Window->GetWindowMode()), FMath::RoundToInt(Size.X), FMath::RoundToInt(Size.Y), FMath::RoundToInt(Pos.X), FMath::RoundToInt(Pos.Y)));
    }
    else
    {
        UE_LOG(LogGraphicsAutoTune, Display, TEXT("macOS: moving the window from %d,%d to %d,%d (under the menu bar, clear of the Dock; %d of %d)"),
            FMath::RoundToInt(Pos.X), FMath::RoundToInt(Pos.Y), WantPos.X, WantPos.Y, MacWindowFailures + 1, GfxAutoTune::MacWindowMaxFailures);
        Window->MoveWindowTo(FVector2D(WantPos));
        RecordMacWindow(FString::Printf(TEXT("moved from %d,%d to %d,%d (%d of %d)"), FMath::RoundToInt(Pos.X), FMath::RoundToInt(Pos.Y), WantPos.X, WantPos.Y,
            MacWindowFailures + 1, GfxAutoTune::MacWindowMaxFailures));
    }
    ++MacWindowFailures;            // cleared as soon as the window is right
    MacWindowLastApply = Now;
    MacWindowWrongSince = Now;      // the settle counts from this correction
#else
    (void)Now;
#endif
}

const TCHAR* UGraphicsAutoTuneSubsystem::ProfileName(EPowerProfile Which)
{
    return Which == EPowerProfile::Battery ? TEXT("Battery") : TEXT("AC");
}

FString UGraphicsAutoTuneSubsystem::ProfileKey(EPowerProfile Which, const TCHAR* Key)
{
    return FString(Key) + ProfileName(Which);
}

UGraphicsAutoTuneSubsystem::EPowerProfile UGraphicsAutoTuneSubsystem::CurrentPowerProfile() const
{
    return GfxAutoTune::IsOnBatteryPower() ? EPowerProfile::Battery : EPowerProfile::AC;
}

bool UGraphicsAutoTuneSubsystem::IsProfileTuned(EPowerProfile Which) const
{
    return ProfileGetInt(Which, TEXT("TunedVersion")) >= GfxAutoTune::TuneVersion;
}

int32 UGraphicsAutoTuneSubsystem::ProfileGetInt(EPowerProfile Which, const TCHAR* Key, int32 Default) const
{
    int32 Value = Default;
    GConfig->GetInt(GfxAutoTune::ConfigSection, *ProfileKey(Which, Key), Value, GGameUserSettingsIni);
    return Value;
}

void UGraphicsAutoTuneSubsystem::ProfileSetInt(EPowerProfile Which, const TCHAR* Key, int32 Value)
{
    GConfig->SetInt(GfxAutoTune::ConfigSection, *ProfileKey(Which, Key), Value, GGameUserSettingsIni);
}

void UGraphicsAutoTuneSubsystem::ProfileSetString(EPowerProfile Which, const TCHAR* Key, const FString& Value)
{
    GConfig->SetString(GfxAutoTune::ConfigSection, *ProfileKey(Which, Key), *Value, GGameUserSettingsIni);
}

bool UGraphicsAutoTuneSubsystem::ReadProfile(EPowerProfile Which, FProfile& Out) const
{
    FString Text;
    if (!GConfig->GetString(GfxAutoTune::ConfigSection, *ProfileKey(Which, TEXT("Profile")), Text, GGameUserSettingsIni))
    {
        return false;
    }
    TArray<FString> Parts;
    Text.ParseIntoArray(Parts, TEXT(","), true);
    if (Parts.Num() != 3)
    {
        return false;
    }
    Out.Rung = FMath::Clamp(FCString::Atoi(*Parts[0]), 0, 2);
    Out.Fps = FCString::Atoi(*Parts[1]) >= 60 ? 60 : 30;
    Out.Percent = FMath::Clamp(FCString::Atoi(*Parts[2]), GfxAutoTune::MinScreenPercent, 100);
    return true;
}

void UGraphicsAutoTuneSubsystem::WriteProfile(EPowerProfile Which, const FProfile& Settings)
{
    ProfileSetString(Which, TEXT("Profile"), FString::Printf(TEXT("%d,%d,%d"), Settings.Rung, Settings.Fps, Settings.Percent));
    GConfig->Flush(false, GGameUserSettingsIni);
}

int32 UGraphicsAutoTuneSubsystem::ReadFinishedFailures(EPowerProfile Which) const
{
    // The count belongs to one TuneVersion: a new version gets a fresh chance (it may be the fix for what failed).
    const int32 Count = ProfileGetInt(Which, TEXT("FinishedFailures"));
    const int32 ForVersion = ProfileGetInt(Which, TEXT("FinishedFailuresFor"));
    return ForVersion == GfxAutoTune::TuneVersion ? FMath::Max(0, Count) : 0;
}

void UGraphicsAutoTuneSubsystem::WriteFinishedFailures(EPowerProfile Which, int32 Count)
{
    ProfileSetInt(Which, TEXT("FinishedFailures"), Count);
    ProfileSetInt(Which, TEXT("FinishedFailuresFor"), GfxAutoTune::TuneVersion);
    GConfig->Flush(false, GGameUserSettingsIni);
}

void UGraphicsAutoTuneSubsystem::RecordTrace(const FString& What)
{
    // Shipping writes no log. The last three decisions, newest first, so a launch that "did nothing" can be read
    // afterwards: which power state it saw, whether the menu was found, whether the settle gate opened, and so on.
    FString Older1, Older2;
    GConfig->GetString(GfxAutoTune::ConfigSection, TEXT("Trace1"), Older1, GGameUserSettingsIni);
    GConfig->GetString(GfxAutoTune::ConfigSection, TEXT("Trace2"), Older2, GGameUserSettingsIni);
    GConfig->SetString(GfxAutoTune::ConfigSection, TEXT("Trace3"), *Older2, GGameUserSettingsIni);
    GConfig->SetString(GfxAutoTune::ConfigSection, TEXT("Trace2"), *Older1, GGameUserSettingsIni);
    GConfig->SetString(GfxAutoTune::ConfigSection, TEXT("Trace1"), *FString::Printf(TEXT("%s @ %s"), *What, *FDateTime::UtcNow().ToIso8601()), GGameUserSettingsIni);
    GConfig->Flush(false, GGameUserSettingsIni);
}

void UGraphicsAutoTuneSubsystem::RecordMacWindow(const FString& What)
{
    // Shipping writes no log: the repair's last action goes to the ini at once, so a Shipping run can be read afterwards.
    GConfig->SetString(GfxAutoTune::ConfigSection, TEXT("MacWindow"), *FString::Printf(TEXT("%s @ %s"), *What, *FDateTime::UtcNow().ToIso8601()), GGameUserSettingsIni);
    GConfig->Flush(false, GGameUserSettingsIni);
}

void UGraphicsAutoTuneSubsystem::RecordOutcome(EPowerProfile Which, const FString& Result, bool bFinished)
{
    if (bFinished)
    {
        ProfileSetInt(Which, TEXT("TunedVersion"), GfxAutoTune::TuneVersion);
        ProfileSetInt(Which, TEXT("Attempts"), 0);
    }
    const FString Stamp = FDateTime::UtcNow().ToIso8601();
    ProfileSetString(Which, TEXT("LastResult"), Result);
    ProfileSetString(Which, TEXT("LastRunUtc"), Stamp);
    // Plain LastResult stays as the one-line summary for anyone reading the ini by hand.
    GConfig->SetString(GfxAutoTune::ConfigSection, TEXT("LastResult"), *FString::Printf(TEXT("%s: %s"), ProfileName(Which), *Result), GGameUserSettingsIni);
    GConfig->SetString(GfxAutoTune::ConfigSection, TEXT("LastRunUtc"), *Stamp, GGameUserSettingsIni);
    GConfig->Flush(false, GGameUserSettingsIni);
}

bool UGraphicsAutoTuneSubsystem::SetRow(const TCHAR* RowName, int32 Index)
{
    UUserWidget* Row = Menu.IsValid() ? Cast<UUserWidget>(Menu->GetWidgetFromName(FName(RowName))) : nullptr;
    if (!Row)
    {
        UE_LOG(LogGraphicsAutoTune, Warning, TEXT("Options menu row %s not found"), RowName);
        return false;
    }
    const int32 NumOptions = GfxAutoTune::GetButtonOptions(Row).Num();
    if (NumOptions == 0)
    {
        UE_LOG(LogGraphicsAutoTune, Warning, TEXT("Options menu row %s has no options"), RowName);
        return false;
    }
    return GfxAutoTune::CallWithInt(Row, TEXT("ByGlobalSetting"), TEXT("NewButtonIndex"), FMath::Clamp(Index, 0, NumOptions - 1));
}

bool UGraphicsAutoTuneSubsystem::SetRowIfDifferent(const TCHAR* RowName, int32 Index)
{
    // Used for rows whose command re-issues r.SetRes (display mode, resolution): skip no-op window changes.
    return GetRowIndex(RowName) == Index ? true : SetRow(RowName, Index);
}

int32 UGraphicsAutoTuneSubsystem::GetRowIndex(const TCHAR* RowName) const
{
    const UUserWidget* Row = Menu.IsValid() ? Cast<UUserWidget>(Menu->GetWidgetFromName(FName(RowName))) : nullptr;
    return GfxAutoTune::GetIntProperty(Row, TEXT("ButtonIndex"), INDEX_NONE);
}

int32 UGraphicsAutoTuneSubsystem::FindDisplayResolutionIndex() const
{
    // In (windowed) fullscreen the viewport is the display the game is on, in physical pixels; otherwise use the
    // primary display.
    FIntPoint Size(0, 0);
    float DpiScale = 1.f;
    UGameViewportClient* Viewport = GetGameInstance() ? GetGameInstance()->GetGameViewportClient() : nullptr;
    const TSharedPtr<SWindow> Window = Viewport ? Viewport->GetWindow() : nullptr;
    if (Window.IsValid())
    {
        DpiScale = FMath::Max(1.f, Window->GetDPIScaleFactor());
        if (Window->GetWindowMode() != EWindowMode::Windowed)
        {
            FVector2D ViewportSize(0, 0);
            Viewport->GetViewportSize(ViewportSize);
            Size = FIntPoint(static_cast<int32>(ViewportSize.X), static_cast<int32>(ViewportSize.Y));
        }
    }
    if (Size.X <= 0 || Size.Y <= 0)
    {
        FDisplayMetrics Metrics;
        FDisplayMetrics::RebuildDisplayMetrics(Metrics);
        Size = FIntPoint(Metrics.PrimaryDisplayWidth, Metrics.PrimaryDisplayHeight);
    }

    const UObject* Row = Menu.IsValid() ? Menu->GetWidgetFromName(FName(GfxAutoTune::ResolutionRow)) : nullptr;
    const TArray<FString> Options = GfxAutoTune::GetButtonOptions(Row);
    // The row lists GetSupportedFullscreenResolutions: physical pixels on Windows; on macOS the RHI divides the
    // display modes by the backing scale, so also try the size in points and in points / scale.
    const float Divisors[] = { 1.f, DpiScale, DpiScale * DpiScale };
    for (const float Divisor : Divisors)
    {
        const FString Wanted = FString::Printf(TEXT("%dx%d"), FMath::RoundToInt(Size.X / Divisor), FMath::RoundToInt(Size.Y / Divisor));
        const int32 Index = Options.IndexOfByKey(Wanted);
        if (Index != INDEX_NONE)
        {
            return Index;
        }
    }

    // No exact match. On macOS there cannot be one: the Metal RHI divides every display mode by the Retina backing
    // scale when it builds this list (MetalRHI.cpp, RHIGetAvailableResolutions), so the list tops out at half the
    // display in each axis — 1440x932 for a 2880x1864 panel, which is the desktop's size in points and renders at
    // full resolution through bAllowHighDPIInGameMode. Rather than leave the row alone, which is what left Macs at
    // whatever the menu happened to default to, take the largest entry that still fits inside the display.
    int32 Best = INDEX_NONE;
    int64 BestArea = 0;
    int32 Smallest = INDEX_NONE;
    int64 SmallestArea = 0;
    for (int32 Index = 0; Index < Options.Num(); ++Index)
    {
        FString WidthText, HeightText;
        if (!Options[Index].Split(TEXT("x"), &WidthText, &HeightText))
        {
            continue;
        }
        const int64 Width = FCString::Atoi(*WidthText);
        const int64 Height = FCString::Atoi(*HeightText);
        if (Width <= 0 || Height <= 0)
        {
            continue;
        }
        const int64 Area = Width * Height;
        if (Smallest == INDEX_NONE || Area < SmallestArea)
        {
            Smallest = Index;
            SmallestArea = Area;
        }
        if (Width <= Size.X && Height <= Size.Y && Area > BestArea)
        {
            Best = Index;
            BestArea = Area;
        }
    }
    const int32 Chosen = Best != INDEX_NONE ? Best : Smallest;      // every entry bigger than the display: take the least bad
    if (Chosen == INDEX_NONE)
    {
        UE_LOG(LogGraphicsAutoTune, Warning, TEXT("The menu's resolution row has no usable entries (%d); leaving it as it is"), Options.Num());
        return INDEX_NONE;
    }
    UE_LOG(LogGraphicsAutoTune, Display, TEXT("Display is %dx%d and the menu's list has no such entry (%d entries); choosing its largest that fits: %s"),
        Size.X, Size.Y, Options.Num(), *Options[Chosen]);
    return Chosen;
}

bool UGraphicsAutoTuneSubsystem::SetScreenPercentRow(double Percent)
{
    // Same effect as the row's Apply button (value into the menu's graphics array + console command), without its click sound.
    UUserWidget* Row = Menu.IsValid() ? Cast<UUserWidget>(Menu->GetWidgetFromName(FName(GfxAutoTune::ScreenScaleRow))) : nullptr;
    if (!Row || !GfxAutoTune::CallWithDouble(Row, TEXT("SetSliderValue"), TEXT("Value"), Percent))
    {
        return false;
    }
    const int32 SettingIndex = GfxAutoTune::GetByteProperty(Row, TEXT("SettingName"), INDEX_NONE);
    const FString Value = FString::SanitizeFloat(Percent);
    if (!GfxAutoTune::SetMenuGraphicValue(Menu.Get(), SettingIndex, Value))
    {
        return false;
    }
    FString Command = GfxAutoTune::GetStringProperty(Row, TEXT("SliderCommand")).TrimEnd();
    if (Command.IsEmpty())
    {
        Command = TEXT("r.ScreenPercentage");
    }
    ExecConsole(Command + TEXT(" ") + Value);
    return true;
}

bool UGraphicsAutoTuneSubsystem::WriteGraphicsSave()
{
    // Write the menu's graphics array into the menu's own save object and save it. The object's key bindings, audio
    // and UI stay exactly as loaded (on a first launch: the class defaults, same as a first launch without tuning),
    // so key bindings are not frozen the way W_Options.SaveOptions would (it sets Saved? on them).
    UUserWidget* MenuWidget = Menu.Get();
    USaveGame* Save = Cast<USaveGame>(GfxAutoTune::GetObjectProperty(MenuWidget, TEXT("AntizeSave")));
    FArrayProperty* Source = MenuWidget ? FindFProperty<FArrayProperty>(MenuWidget->GetClass(), FName(TEXT("MyGraphicIndex"))) : nullptr;
    FArrayProperty* Target = Save ? FindFProperty<FArrayProperty>(Save->GetClass(), FName(TEXT("SaveGraphicIndex"))) : nullptr;
    if (!Save || !Source || !Target || !Source->SameType(Target))
    {
        return false;
    }
    Target->CopyCompleteValue(Target->ContainerPtrToValuePtr<void>(Save), Source->ContainerPtrToValuePtr<void>(MenuWidget));
    return UGameplayStatics::SaveGameToSlot(Save, GfxAutoTune::MenuSlotName, 0);
}

void UGraphicsAutoTuneSubsystem::ExecConsole(const FString& Command) const
{
    UKismetSystemLibrary::ExecuteConsoleCommand(GetGameInstance(), Command, nullptr);
}

void UGraphicsAutoTuneSubsystem::ShowOverlay(EPowerProfile Which)
{
    UGameViewportClient* Viewport = GetGameInstance() ? GetGameInstance()->GetGameViewportClient() : nullptr;
    if (!Viewport || Overlay.IsValid())
    {
        return;
    }
    const FString Title = Which == EPowerProfile::Battery
        ? TEXT("Optimizing graphics for this computer on battery...")
        : TEXT("Optimizing graphics for this computer (plugged in)...");
    Overlay = SNew(SBorder)
        .BorderImage(FCoreStyle::Get().GetBrush(TEXT("WhiteBrush")))
        .BorderBackgroundColor(FLinearColor(0.f, 0.f, 0.f, 0.82f))
        .HAlign(HAlign_Center)
        .VAlign(VAlign_Center)
        [
            SNew(SVerticalBox)
            + SVerticalBox::Slot()
            .AutoHeight()
            .HAlign(HAlign_Center)
            .Padding(0.f, 0.f, 0.f, 12.f)
            [
                SNew(STextBlock)
                .Text(FText::FromString(Title))
                .Font(FCoreStyle::GetDefaultFontStyle("Regular", 30))
                .ColorAndOpacity(FLinearColor::White)
            ]
            + SVerticalBox::Slot()
            .AutoHeight()
            .HAlign(HAlign_Center)
            [
                SAssignNew(OverlayStatus, STextBlock)
                .Font(FCoreStyle::GetDefaultFontStyle("Regular", 18))
                .ColorAndOpacity(FLinearColor(0.8f, 0.8f, 0.8f, 1.f))
            ]
        ];
    Viewport->AddViewportWidgetContent(Overlay.ToSharedRef(), 10000);
}

void UGraphicsAutoTuneSubsystem::UpdateOverlay()
{
    if (OverlayStatus.IsValid())
    {
        OverlayStatus->SetText(FText::FromString(FString::Printf(
            TEXT("Measuring performance (step %d). This happens once on battery and once plugged in, and takes about half a minute."), Results.Num() + 1)));
    }
}

void UGraphicsAutoTuneSubsystem::HideOverlay()
{
    UGameInstance* GameInstance = GetGameInstance();
    UGameViewportClient* Viewport = GameInstance ? GameInstance->GetGameViewportClient() : nullptr;
    if (Overlay.IsValid() && Viewport)
    {
        Viewport->RemoveViewportWidgetContent(Overlay.ToSharedRef());
    }
    Overlay.Reset();
    OverlayStatus.Reset();
}

void UGraphicsAutoTuneSubsystem::SetGameplayInputBlocked(bool bBlocked)
{
    if (bBlocked == bInputBlocked)
    {
        return;
    }
    APlayerController* PC = TunedController.Get();
    APawn* Pawn = TunedPawn.Get();
    if (bBlocked)
    {
        if (!PC)
        {
            return;
        }
        // Pawn input off (movement, look and the pawn's Escape binding that opens the options menu). Remember whether
        // it was on, so a pawn whose input the game itself had switched off is left that way.
        bPawnInputWasEnabled = Pawn && Pawn->InputEnabled();
        if (bPawnInputWasEnabled)
        {
            Pawn->DisableInput(nullptr);
        }
        PC->SetIgnoreMoveInput(true);
        PC->SetIgnoreLookInput(true);
        bInputBlocked = true;
    }
    else
    {
        if (PC)
        {
            PC->SetIgnoreMoveInput(false);
            PC->SetIgnoreLookInput(false);
        }
        if (bPawnInputWasEnabled && Pawn)
        {
            Pawn->EnableInput(nullptr); // nullptr: re-enable even if the pawn was re-possessed meanwhile
        }
        bPawnInputWasEnabled = false;
        bInputBlocked = false;
    }
}
