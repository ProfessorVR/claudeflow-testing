// Copyright Epic Games, Inc. All Rights Reserved.

using UnrealBuildTool;
using System.Collections.Generic;

public class awsTutorialTarget : TargetRules
{
	public awsTutorialTarget(TargetInfo Target) : base(Target)
	{
		Type = TargetType.Game;
		bValidateFormatStrings = true;
		DefaultBuildSettings = BuildSettingsVersion.V5;
		IncludeOrderVersion = EngineIncludeOrderVersion.Unreal5_4;
		ExtraModuleNames.Add("awsTutorial");

		// macOS (2026-09-21): keep the engine's replacement operator new/delete PRIVATE to the executable.
		// Unreal replaces the global C++ allocator (ModuleBoilerplate.h); on macOS dyld coalesces every framework's
		// weak libc++ operators onto the executable's exported ones, so Apple's own frameworks allocate and free through
		// FMemory. Apple's VoiceProcessingIO (echo cancellation) frees blocks it obtained from malloc through
		// operator delete[] - at unit creation on macOS 26 and at disposal on macOS 15 - and the engine's allocator
		// fatals on the unrecognized block. With the operator symbols un-exported, frameworks keep libc++'s allocator
		// and the game keeps its own; the boundary is C APIs only (CoreAudio, Metal, CEF, ogg/vorbis, TBB), so nothing
		// crosses. Proven with plans/MacOS_UE_Fix/tools/mac/alloc_probe (visible: 3 foreign frees; hidden: none).
		if (Target.Platform == UnrealTargetPlatform.Mac && ProjectFile != null)
		{
			string UnexportedList = System.IO.Path.Combine(ProjectFile.Directory.FullName, "Build", "Mac", "unexported_operators.txt");
			AdditionalLinkerArguments = (AdditionalLinkerArguments ?? "") + " -Wl,-unexported_symbols_list," + UnexportedList;
		}
	}
}
